﻿using System;

// 핵심 3. 키워드와 식별자
// A : C# 키워드 이고, C++ 키워드가 아니면..

class @int
{
    public void show() { Console.WriteLine("int.show()"); }
}

class where  // where 는 C# 키워드 입니다.
{ }

class Program
{
    public static void Main()
    {
        int n;
    }

    public static void foo<T>(T a) where T : new()
    {
    }
}








// 문맥의존 키워드 : add, dynamic, into, partial, when, ascending, equals, join, remove,where
//                  async, from, let, select, yield, await, get, nameof, set, by, global, on,
//                  on, value, descending, group, orderby, var

