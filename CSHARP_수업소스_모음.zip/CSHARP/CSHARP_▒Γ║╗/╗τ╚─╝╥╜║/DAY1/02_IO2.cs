﻿using System;  // namespace open
using static System.Console; // 특정 클래스의 static method를
                            // 클래스 이름 없이 사용하고 싶을때

class Program
{
    public static void Main()
    {
        Console.WriteLine("Hello C#");
        WriteLine("Hello C#");
    }
}