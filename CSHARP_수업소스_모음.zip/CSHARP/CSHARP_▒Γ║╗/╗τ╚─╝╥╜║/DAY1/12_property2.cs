﻿using System;

// automatic property
// property1.cs 복사.

