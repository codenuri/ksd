﻿using System;
using System.Reflection;

// 타입 정보 얻기
class Program
{
    public static void Main()
    {
        int n = 10;
        var n2 =  n; // 우변의 수식을 조사해서 좌변의 타입을 결정해
                     // 달라. C++ auto

        // 타입을 조사하는 방법 - Type 클래스 사용
        //Type t1 = n2.GetType(); // 변수의 타입 정보 조사
        Type t1 = typeof(int);    // 타입의 타입 정보

        Console.WriteLine(t1.Name);

        MethodInfo[] mi = t1.GetMethods();

        foreach( MethodInfo f in mi )
        {
            Console.WriteLine(f.ToString());
        }
    }
}







