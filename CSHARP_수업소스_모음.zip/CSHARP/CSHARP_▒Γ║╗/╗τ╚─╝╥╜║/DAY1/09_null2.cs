﻿using System;

// Nullable 타입, ?, ??

class Program
{
    // 함수 실패시 반환타입이
    // 참조 타입일때 : null 반환
    // 값   타입일때 : 약속된 값 반환

    // 값타입도 값없음 상태를 나타낼수 없을까 ?
    //public static int Foo() { return -1; }

    // Nullable<타입> : 타입 + bool
    //public static Nullable<int> Foo() { return null; }

    // int? : Nullable<int>의 축약형
    public static int? Foo() { return null; }

    public static void Main()
    {
        int? ret = Foo();
        if (ret == null)
            Console.WriteLine("실패");

        // int 와 int? 의 집합관계
        int n1 = 10;
        int? n2 = n1; // ok

        //int n3 = n2; // error

        int n3 = (int)n2; // ok..  하지만 n2가 null 이면 예외

        // n2(int?)에 있는 값을 꺼내는 제일좋은 방법은 ?

        var n4 = n2;     // n4의 타입 - int ?
        var n5 = n2 ?? 0;// n5의 타입 - int

        Type t1 = n2.GetType();
        Type t2 = n5.GetType();

        Console.WriteLine(t1.Name);
        Console.WriteLine(t2.Name);

        //Console.WriteLine()
    }
}







