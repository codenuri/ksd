﻿using System;

// 변환 연산자
// 
class Point
{
    public int x = 0;
    public int y = 0;
    public Point(int a, int b) { x = a; y = b; }
    public void Dump() { Console.WriteLine("x = {0}, y = {0}", x, y); }

    // 사용자 정의 변환 함수
    // int => Point : operator Point(int)
    // Point => int : operator int(Point)
    public static explicit operator Point(int n)
    {
        Console.WriteLine("operator point");
        Point p = new Point(n, n);
        return p;
    }
}
class Program
{
    public static void Main()
    {
        int n = 10;
//        Point p = (Point)n;  // int => Point 변환이 필요 하다.
                             // 사용자 정의 변환 함수를 제공하면된다


 //       Point p = n as Point; // 사용자 정의 변환 연산자를 검색하지
                                // 않는다.

        p.Dump();

        foo(p);
    }

    public static void foo<T>(T a)
    {
        // Point p = a;
        // Point p = (Point)a;
        Point p = a as Point;   // Point
    }
}



