﻿using System;

// value_type 과 reference_type 조사
// C
//int n;
//int x[3];

class Program
{
    public static void Main()
    {
        // 1. Type 객체의 멤버 함수 사용

        // C# 배열 만들기
        // 배열은 value type 일까요 ? reference type 일까요?
        int[] x = new int[] { 1, 2, 3, 4, 5 };
        int[] y = x;

        x[0] = 10;
        Console.WriteLine($"{y[0]}");  // 10

        Type t = x.GetType();

        Console.WriteLine(t.IsValueType);

        // 배열의 복제본 만들기
        //int[] z = x; // 배열자체는 공유

        // Clone 의 반환값은 object 타입 입니다.
        // 반환값은 캐스팅해서 사용해야 합니다. - 불편합니다.
        // 내일 generic 
        int[] z = (int[])x.Clone(); // 배열의 복사본을 만들어서 z가 사용


        x[0] = 100;
        Console.WriteLine($"{z[0]}");
    }
}





