﻿using System;

// var

class Program
{
    public static void Main()
    {
        int n1 = 10;
        var n2 = n1;





    }
}