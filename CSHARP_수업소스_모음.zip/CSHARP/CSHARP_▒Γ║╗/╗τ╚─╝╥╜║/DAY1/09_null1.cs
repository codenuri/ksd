﻿using System;

// null1.cs

// ?? : 널 접합 연산자(null-coalescing operator)
// ?  : 널 조건부 연산자(null-conditional operator, 'Elvis' operator)

class Car
{
    public void Go() { Console.WriteLine("Car Go"); }
}

class Program
{
    public static Car CreateCar(int speed)
    {
        if (speed < 200)
            return new Car();
        return null;
    }
    public static void Main()
    {
        Car c = CreateCar(300);

        // 아주 널리 사용하는 코드.!!
        if (c != null)
        {
            c.Go();
        }

        // 1. 널 조건부 연산자(null contidional operator, elvis operator)
        c?.Go(); // 위 코드와 완전히 동일한 코드
                 // null 이 아니면 Go 호출. null 이면 NOP

        //a?.b?.c?.d?.foo();

        // 3. 널 접합 연산자(null coalescing operator) - ??

        Car c2 = CreateCar(100) ?? new Car();

        c2.Go();

        //string s = "kim";
        string s = null;

        string name = s ?? "이름없음";

        Console.WriteLine(name);
    }
}

// ?    ??
