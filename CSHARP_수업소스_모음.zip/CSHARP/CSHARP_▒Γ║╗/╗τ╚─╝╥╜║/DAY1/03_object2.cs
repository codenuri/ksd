﻿using System;

// 모든 타입은 object로 부터 파생 된다.
// object : 4개의 instance method 와 2개의 static method를 가지고 있다
/*
struct Int32 : object   // int 의 진짜 이름은 Int32 입니다.
{
}
*/

class Program
{
    public static void Foo(object o)
    {
        int n;

        string s = o.ToString();

        Console.WriteLine(s);
    }

    public static void Main()
    {
        // object 는 모든 타입의 기반 클래스이므로...
        // 모든 타입을 Foo로 전달가능.
        Foo(10);
        Foo(3.4);
        Foo("aa");
    }
}