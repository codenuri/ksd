﻿using System;

// 핵심 5. 캐스팅
// is, as, 캐스트

class Animal { };

class Dog : Animal
{
    public void Cry() { Console.WriteLine("Dog Cry"); }
}

class Program
{
    public static void Main()
    {
        // upcasting : 기반 클래스 참조로 파생 클래스를 가리키는것
        Animal a = new Dog();

        //a.Cry();  // error. 하지만 파생 클래스 고유 멤버 접근안됨.
        ((Dog)a).Cry(); // ok. 하지만 a가 반드시 Dog 이어야 한다.

        
        // a 가 Dog 인지 조사하는 방법
        // 방법 1. is 연산자
        if (a is Dog)
        {
            Dog d = (Dog)a;
            d.Cry();
        }
        else
            Console.WriteLine("a는 Dog가 아닙니다.");

        // 방법 2. as 연산자.
        Dog d2 = a as Dog;

        if ( d2 == null )
        {
            Console.WriteLine("Dog 아님");
        }
        else
        {
            d2.Cry();
        }

        // 정리
        // is 연산자 : 타입 조사
        // 캐스팅은 2개
        // Dog d = (Dog)a;    // 실패시 예외 발생
        // Dog d = a as Dog;  // 실패시 null
    }
}




