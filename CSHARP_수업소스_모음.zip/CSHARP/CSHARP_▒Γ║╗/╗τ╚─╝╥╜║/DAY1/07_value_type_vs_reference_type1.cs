﻿using System;

// 핵심 5. value_type vs reference type

// C/C++ 언어를 생각해 봅시다.

//Point p1(1,2);
//Point* p2 = new Point(1, 2);

// C/C++ : 객체가 놓일 메모리의 선택 - 타입사용자가 결정
// C# , java  : 객체가 놓일 메모리의 선택 -  타입 설계자가 결정

// C#에서
// struct : stack 에 객체를 만든다. - value type이라고 부른다.
// class  : 힙에 객체를 만든다 - reference type이라고 부른다.


// 스택 객체(value type), 스택에 값으로 만들어 진다.
struct SPoint
{
    public int x;
    public int y;
}
class CPoint   // 힙객체 - reference type
{
    public int x;
    public int y;
}

class Program
{

    public static void Main()
    {
        SPoint sp1;                 // 객체 생성
        SPoint sp2 = new SPoint();  // 객체 생성 

        CPoint cp1;                 // 참조 변수만 생성
        CPoint cp2 = new CPoint();  // 객체 생성후 cp2참조변수가 
                                    // 가르킨다.
        sp1.x = 10;
        sp2.x = 10;
        cp1.x = 10;
        cp2.x = 10;
    }

    /*
    public static void Main()
    {
        SPoint sp1 = new SPoint();
        SPoint sp2 = sp1;

        sp1.x = 100;
        Console.WriteLine("sp1.x = {0}, sp2.x = {1}", sp1.x, sp2.x);

        CPoint cp1 = new CPoint();
        CPoint cp2 = cp1;

        cp1.x = 100;
        Console.WriteLine("cp1.x = {0}, cp2.x = {1}", cp1.x, cp2.x);


    }
    */
}



// value type     : numeric primitive type, struct, enum
// reference type : string, array, class, interface, delegate