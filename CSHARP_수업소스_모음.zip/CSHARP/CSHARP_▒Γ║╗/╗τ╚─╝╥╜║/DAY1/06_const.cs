﻿using System;

// 핵심 4. 컴파일 시간 상수 vs 실행시간 상수

// csc 4_const.cs /r:Const.dll

class Program
{
    public static int n = 10;
    public const int c1 = 10; // 컴파일 시간 상수.
                            // 컴파일러가 c1을 만나면 10으로 치환

    public static readonly int c2 = 10; // 실행시간 상수
                            // 실행시간에 값을 변경할수 없다.

    public static void Main()
    {
        //   Console.WriteLine(c1);
        //   Console.WriteLine(c2);

        Console.WriteLine(Const.const_value);
        Console.WriteLine(Const.readonly_value);

    }
}

// csc /r:Const.dll 06_const.cs




















// const    : 컴파일   시간상수, method 내에서도 만들수 있다
//            primitive, enum, string, null 만 가능.
// readonly : 실행시간 시간상수, method 내에서도 만들수 없다

