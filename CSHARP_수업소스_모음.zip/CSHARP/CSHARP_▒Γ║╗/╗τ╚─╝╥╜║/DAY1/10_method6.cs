﻿using System;

// 확장 메소드

class Car
{
    public void Go() { Console.WriteLine("Car Go"); }
}

class Extension
{
    public static void Main()
    {
        Car c = new Car();
        c.Go();
        c.Stop();  // CarExtension.Stop(c);
    }
}