﻿using System;

// this를 사용한 다른 생성자 호출

class Point
{
    public int x;
    public int y;

    public Point(int a, int b) { x = a; y = b; Console.WriteLine("Point(int, int)"); }
    public Point()  { Console.WriteLine("Point()"); }
}
 

class Program
{
    public static void Main()
    {
        Point p1 = new Point(0, 0);
        Point p2 = new Point();

        Console.WriteLine($"{p2.x}, {p2.y}");
    }
}