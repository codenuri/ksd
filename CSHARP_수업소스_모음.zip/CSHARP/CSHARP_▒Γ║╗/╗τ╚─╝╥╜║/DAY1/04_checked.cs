﻿using System;

// 안전한 코드를 만들기 위한 문법들

class Program
{
    public static void Main()
    {
     //   int n;
     //   Console.WriteLine(n); // error. 초기화되지 않은 변수 사용안됨

        //int n1 = int.MaxValue + 1; // error
        int n1 = int.MaxValue;

        //int n2 = n1 + 1;// 컴파일 , 실행시 모두 에러가 없다.

        int n2 = checked(n1 + 1);// 실행시 값을 검사해서
                                // 오버플로 발생시 예외전달

        Console.WriteLine($"{n2}");

        int n3 = unchecked(int.MaxValue + 1);  // compile error
    }
}


