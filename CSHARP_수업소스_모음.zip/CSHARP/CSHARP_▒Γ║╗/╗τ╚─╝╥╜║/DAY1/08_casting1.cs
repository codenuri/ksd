﻿using System;

// 
// C/C++ : 모든 기본 타입은 암시적 변환된다.
// C#    : 모든 기본 타입은 데이타 손실이 없을때 암시적 변환된다.
// 함수형언어 : 모든 변환이 안된다.
class Program
{
    public static void Main()
    {
        int n1 = 3;
        double d = n1; // 데이타 손실이 없는 변환 - promotion
                        // ok.

        int n2 = d; // error. 데이타 손실이 있는 변환 - error
        int n2 = (int)d; // ok
    }
}