﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 지연된 실행, ToList(), 캡쳐된 변수

class Program
{
    public static void Main()
    {
        IList<int> list = new List<int> { 1, 2, 3 };

        //var result = list.Select(n => n * 10);

        // 1. Select 절을 가지고 각 요소에 적용할 함수를 만듭니다.
        // 2. result 안에는 list에 대한 참조와 1에서 만든 함수가 보관됩니다.
        // 핵심은 함수가 아직 적용되지는 않은 상태 입니다.

        IEnumerable<int> result = list.Select(n => n * 10);

        list.Clear(); 

        foreach (int n in result)
            Console.WriteLine(n); // 결과 어떻게 나올까요 ?
    }
}




