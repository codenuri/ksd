﻿using System;
using System.Diagnostics; // Process 클래스
using System.Threading;

class Program
{
    public static void Main()
    {
        Process.Start("calc.exe"); //

        // 프로세스 관련 모든 기능은 Process 클래스 사용
        
        Process[] arr = Process.GetProcesses();

        foreach (Process p in arr)
            Console.WriteLine($"{p.ProcessName}");
    }
}
