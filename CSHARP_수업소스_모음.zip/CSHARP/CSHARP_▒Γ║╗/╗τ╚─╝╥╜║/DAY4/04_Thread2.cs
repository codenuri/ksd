﻿using System;
using System.Threading;

// background, join, suspend, resume, state

class Program
{
    public static void Foo()
    {
        for (int i = 0; i < 1000; i++)
            Console.Write("Foo");
    }

    public static void Main(string[] args)
    {
        Thread t = new Thread(Foo);
        t.Start();

        // foreground 스레드 : 주스레드가 종료 되어도 계속 실행될수 있는경우
        // background 스레드 : 주스레드가 종료 되면 스레드도 종료
        t.IsBackground = true;

        t.Join(); // 새로운 스레드가 종료 될때 까지 대기

        Console.WriteLine("main finish");

    }
}
