﻿using System;
using System.Collections;         // IEnumerable
using System.Collections.Generic; // IEnumerable<T>
using static System.Console;

class Node<T>
{
    public T data = default(T);
    public Node<T> next = null;

    public Node(T d, Node<T> n) { data = d; next = n; }
}

// 핵심. 열거자(IEnumerator<T> 로 부터 파생된 클래스) 가 없다.

class MyLinkedList<T> : IEnumerable<T>
{
    // yield 를 사용한 반복자 만들기.
    // 핵심 : 반복자 객체 없이 그냥 값을 리턴합니다.
    public IEnumerator<T> GetEnumerator()
    {
        Console.WriteLine("GetEnumerator");
        Node<T> current = head;
        while( current != null )
        {
            yield return current.data;
            current = current.next;
        }
    }

   
    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }
   
    public Node<T> head = null;

    public void AddFirst(T value)
    {
        head = new Node<T>(value, head);
    }
}

class Program
{
    public static void Main()
    {
        MyLinkedList<int> s = new MyLinkedList<int>();

        s.AddFirst(10);
        s.AddFirst(20);
        s.AddFirst(30);
        s.AddFirst(40);

        Console.WriteLine("AAA");
        IEnumerator<int> it = s.GetEnumerator(); // 실제 호출안됨
        Console.WriteLine("BBB");

        while (it.MoveNext()) // 이순간 GetEnumerator() 호출
        {
            Console.WriteLine("After MoveNext");
            Console.WriteLine(it.Current); 
            
        }

    }
}