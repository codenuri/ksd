﻿using System;
using System.Threading;

// Thread1.cs

class Program
{
    //public static void Foo()
    //public static void Foo(object obj)
    public static void Foo(string obj)
    {
        for (int i = 0; i < 1000; i++)
            Console.Write("Foo ");
    }

    public static void Main(string[] args)
    {
        // Thread 만들기 1
        //Thread t = new Thread(Foo);
        //t.Start(); // 이 순간 스레드가 생성되어서 Foo를 실행합니다.
        //t.Start("hello"); // 스레드 함수에 인자 전달 - object로 받아야 합니다.

        // 스레드 함수로 람다 표현식 사용가능
        Thread t = new Thread(() => Foo("hello"));
        t.Start();


        for (int i = 0; i < 1000; i++)
            Console.Write("Main ");
    }
}
