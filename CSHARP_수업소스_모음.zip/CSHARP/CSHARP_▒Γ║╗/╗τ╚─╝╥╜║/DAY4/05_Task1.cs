﻿using System;
using System.Threading;
using System.Threading.Tasks;

// Task 개념.
// run() 반환값 : task


class Task1
{
    public static void Foo()
    {
        for (int i = 0; i < 1000; i++)
            Console.Write("Foo ");
    }

    public static void Main()
    {
        // 스레드 풀에 있는 스레드에게 작업을 시킨다.

        //Task.Factory.StartNew(Foo); // 스레드 풀에 작업 요청

        // .net framework 4.5 이상으로 설정..
        Task t = Task.Run((Action)Foo);

       Console.WriteLine(t.IsCompleted);

        t.Wait();

        Console.WriteLine(t.IsCompleted);


        /*
        Thread t1 = new Thread(Foo);      
        t1.Start();

        Thread.Sleep(5000);

        Thread t2 = new Thread(Foo);
        t2.Start();
        */
    }
}

