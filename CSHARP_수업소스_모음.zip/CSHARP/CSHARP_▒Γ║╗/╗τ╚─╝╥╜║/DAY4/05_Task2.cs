﻿using System;
using System.Threading;
using System.Threading.Tasks;

// TaskCreationOptions.LongRunning

class Task1
{
    public static void Foo(string name)
    {
        Console.WriteLine($"{name} : {Thread.CurrentThread.ManagedThreadId}");
        Thread.Sleep(3000);
        Console.WriteLine($"{name} end");
    }
    public static void Main()
    {
        Console.WriteLine($"Main : {Thread.CurrentThread.ManagedThreadId}");

        /*
        Task.Run(() => Foo("A1"));
        Task.Run(() => Foo("\tB1"));
        Task.Run(() => Foo("\t\tC1"));
        Task.Run(() => Foo("\t\t\tD1"));

        Task.Run(() => Foo("A2"));
        Task.Run(() => Foo("\tB2"));
        Task.Run(() => Foo("\t\tC2"));
        Task.Run(() => Foo("\t\t\tD2"));

        Task.Run(() => Foo("A3"));
        Task.Run(() => Foo("\tB3"));
        Task.Run(() => Foo("\t\tC3"));
        Task.Run(() => Foo("\t\t\tD3"));

        Task.Run(() => Foo("A4"));
        Task.Run(() => Foo("\tB4"));
        Task.Run(() => Foo("\t\tC4"));
        Task.Run(() => Foo("\t\t\tD4"));
        */

        Task.Factory.StartNew(() => Foo("A4"), 
            TaskCreationOptions.LongRunning);

        Console.WriteLine("I am Main");
        Console.ReadLine();
    }
}

