﻿using System;
using System.Collections.Generic;       


// Enumerator

class Program
{
    public static void Main()
    {
        LinkedList<int> s = new LinkedList<int>();

        s.AddFirst(10);
        s.AddFirst(20);
        s.AddFirst(30);
        s.AddFirst(40);

        // 핵심 1. 모든 컬렉션은 아래 인터페이스를 구현해야 한다.
        //         IEnumerable<T>   => GetEnumerator()함수가 있어야한다

        // 핵심 2. 모든 컬렉션의 열거자는 아래 인터페이스를 구현해야 한다
        //         IEnumerator<T>   => MoveNext(), Current 가 있어야한다.

        // 컬렉션의 내용을 열거하려면 "열거자"를 사용한다.
        var it = s.GetEnumerator();

        // 주의 : MoveNext를 먼저 호출해야 처음을 가리킨다.
        while( it.MoveNext() )
        {
            Console.WriteLine(it.Current);
        }

    }
}
