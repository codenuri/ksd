﻿using System;
using System.Collections;               // 1. non generic collections
using System.Collections.Specialized;   // 2. 타입에 특화된 collections
using System.Collections.Generic;       // 3. generic collections
using System.Collections.ObjectModel;   // 4. for Custom collections 
using System.Collections.Concurrent;    // 5. thread safe collections

// Collection : 여러개의 요소를 저장하는 클래스
//               Linked list, 동적배열, tree, hash
class Program
{
    public static void Main()
    {
        // 1. object 를 저장하는 collection
        //    C# 1.0 부터 제공 
        ArrayList c1 = new ArrayList();// 동적배열(크기변경이 가능한 배열)
        c1.Add("AA");
        c1.Add("BB");
        c1.Add(10); // 1. 타입 안전성이 떨어진다. 잘못 사용해도 에러 없음
                    // 2. value type 저장시 Boxing/UnBoxing 발생
        string s = (string)c1[0]; // 3. 값을 꺼낼때 항상 캐스팅이 필요하다
            
        // 2. Generic 기반 컬렉션
        List<int> c2 = new List<int>();
        c2.Add(10);
        c2.Add(10);   // Add(int) 이므로 Boxing 현상이 없다.
        c2.Add("AA"); // error. 타입 안정성이 뛰어나다.
        int n = c2[0]; // 꺼낼때 캐스팅이 필요 없다.


        LinkedList<int> c3 = new LinkedList<int>();
        c3.AddFirst(10);

        // System.Collections.Specialized;
        StringDictionary d = new StringDictionary();

        // System.Collections.Concurrent
        ConcurrentStack<int> cs = new ConcurrentStack<int>();
        cs.Push(10);

    }
}
