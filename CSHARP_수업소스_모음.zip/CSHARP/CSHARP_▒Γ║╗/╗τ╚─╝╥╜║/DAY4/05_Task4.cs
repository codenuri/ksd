﻿using System;
using System.Threading;
using System.Threading.Tasks;

// onCompleted

class Task1
{
    public static int Sum(int n)
    {
        int s = 0;
        for (int i = n; i < n + 10; i++)
            s = s + i;
        Thread.Sleep(1000);
        Console.WriteLine($"{n} : {s}");
        return s;
    }

    public static void Main()
    {
        Task<int> task = Task.Run(() => Sum(10));


        // 아래 코드는 task 스레드의 결과를 주스레드가 대기합니다.
        //int n = task.Result;
        //Console.WriteLine(n);

        var awaiter = task.GetAwaiter();
        // 스레드 풀에 있는 또다른 스레드가 대기
        awaiter.OnCompleted(() => {
            Console.WriteLine($"{Thread.CurrentThread.ManagedThreadId}");
            Console.WriteLine($"{task.Result}");
        });

        Console.WriteLine($"Main : {Thread.CurrentThread.ManagedThreadId}");

        Console.WriteLine("주스레드는 계속 실행");
        
        Console.ReadKey();
    }
}

