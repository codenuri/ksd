﻿using System;
using System.Threading;
using System.Threading.Tasks;

// async, await

class Task1
{
    // 동기 함수 Sum
    public static int Sum(int n)
    {
        int s = 0;
        for (int i = n; i < n + 10; i++)
            s = s + i;
        Thread.Sleep(1000);
        Console.WriteLine($"{n} : {s}");
        return s;
    }
    // 동기 함수를 비동기 함수로 만들기
    public static Task<int> SumAsync( int n)
    {
        return Task.Factory.StartNew(() => Sum(n));
    }

    // await를 사용하려면 함수 앞에 async 가 있어야 합니다.
    public async static void Test()
    {
        // Sum(10); // 동기 호출
        //SumAsync(10); // 비 동기 호출

        //int n = SumAsync(10).Result; // 비 동기 호출에서 결과를 대기

        // 다른 스레드가 대기하려면
        //var awaiter = SumAsync(10).GetAwaiter();
        //awaiter.OnCompleted(() => { });

        int ret = await SumAsync(10);  // 주스레드는 여기 까지만 실행되고
                                       // 이 아래 부분은 새로운 스레드가 실행
        Console.WriteLine(ret);


    }

    public static void Main()
    {
        Test();
        Console.WriteLine("Main");
        Console.ReadKey();
    }
}

