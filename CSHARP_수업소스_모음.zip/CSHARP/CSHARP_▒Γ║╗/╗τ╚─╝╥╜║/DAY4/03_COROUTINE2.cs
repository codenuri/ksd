﻿using System;
using System.Collections;
using System.Threading;
using System.Collections.Generic;

class Program
{
    // C# 코루틴(coroutine) 만들기

    // 1. 반환 값은 반드시 IEnumerator 또는 IEnumerator<T> 가 되어야 합니다.
    // 2. 실행을 중지하고 돌아가려면 yiled return 을 합니다.
    // 3. Main 에서 coroutine을 호출하려면 MoveNext()를 호출합니다.

    public static IEnumerator<int> Foo()
    {
        int cnt = 0;
        while (++cnt <= 10)
        {
            Console.WriteLine($"Foo : {cnt}");
            Thread.Sleep(1000);

            yield return 10; // null 대신 다른 값을 사용해도 됩니다.
        }
    }
    public static void Main()
    {
        IEnumerator it = Foo(); // 이순간 Foo가 호출되지 않습니다.
                                // 실제 호출은 it.MoveNext()입니다.

        int cnt = 0;

        while (++cnt <= 10)
        {
            Console.WriteLine($"Main : {cnt}");
            Thread.Sleep(1000);

            it.MoveNext(); // 이제 Foo가 호출됩니다.
            // it.Current  // Foo의 반환값은 여기 있습니다.
        }
    }
}

