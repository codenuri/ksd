﻿// cafe.naver.com/codenuri  게시판에서  4일차 사전소스 받으시면 됩니다.

















using System;
using System.Threading;

// TimeSpan : "특정 시각(2시 30분)" 또는 "시간의 기간(2시간 30분)"
// DateTime : 그레고리안 날짜, 시간을 관리

class Program
{
    public static void Main()
    {
        TimeSpan ts = new TimeSpan(2, 30, 11);
        Console.WriteLine(ts);

        DateTime dt = DateTime.Now;
        Console.WriteLine(dt);

        Thread.Sleep(1000); // 알고리즘

        DateTime dt2 = DateTime.Now;

        // 알고리즘이 수행한 시간 측정
        TimeSpan ts2 = dt2 - dt;
        Console.WriteLine(ts2);


    }
}
