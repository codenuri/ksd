﻿using System;
using System.Threading;
using System.Threading.Tasks;

// Task 반환값 꺼내기
// C++ Future

class Task1
{
    public static int Foo(string name)
    {
        Console.WriteLine($"{name} : {Thread.CurrentThread.ManagedThreadId}");
        Thread.Sleep(1000);
        Console.WriteLine($"{name} end");

        return 100;
    }
    public static void Main()
    {
        // Task task = Task.Run(()=>Foo("AAA")); // 반환값이 없을때

        Task<int> task = Task.Run(()=>Foo("AAA")); // 반환값이 있을때

        Console.WriteLine("Main 계속 실행됨");

        int n = task.Result; // 이순간 스레드가 종료 될때까지 대기합니다.
        Console.WriteLine($"{n}");

       

    }
}
