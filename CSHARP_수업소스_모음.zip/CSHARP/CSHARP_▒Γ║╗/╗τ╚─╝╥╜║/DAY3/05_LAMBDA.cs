﻿using System;

class Labmda1
{
    public static int Add(int a, int b) { return a + b; }

    public static void Main()
    {
        int v1 = 10; // 정수 리터럴
        double d = 3.4; // 실수 리터럴
        string s = "aa"; // 문자열 리터널
        // 리터널 : 코드에서 사용하는 값

        //Func<int, int, int> plus = Add; // 외부에 만든 함수 이름사용

        // 람다 표현식 : 함수가 필요한 자리에 함수 이름 대신
        //              함수 구현 코드를 직접 작성하는 것
        //              (파라미터리스트) => { 함수 구현 ;}
        //              함수 리터널, 익명의 함수라고도 합니다.
        //Func<int, int, int> plus = (int a, int b) => { return a + b; };

        //Func<int, int, int> plus = (a, b) => { return a + b; };

        Func<int, int, int> plus = (a, b) => a + b; // C#

        //Func<int, int, int> plus = $0 + $1; // swift 표현식


        Console.WriteLine(plus(1, 2)); // 3
    }
}




