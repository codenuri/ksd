﻿using System;


// 모든 타입의 비교 함수의 이름을 동일하게 할수 있도록 규칙을 만들자
// 인터페이스를 도입하자
// C#에서는 크기 비교가 가능한 모든 객체는 아래 인터페이스를구현하고 있다.
/*
// C# 1.0 의 인터페이스...
// object 기반 - Boxing 과 Unboxing 이 많이 발생.. - 성능저하의 원인
interface IComparable
{
    int CompareTo(object obj);
}
*/
// C#2.0의 인터페이스 - generic 기반
/*
interface IComparable<T>
{
    int CompareTo(T obj);
}
*/


struct Point : IComparable,  IComparable<Point>
{
    public int x;
    public int y;
    public Point(int a = 0, int b = 0) { x = a; y = b; }

    public int CompareTo(Point pt)
    {
        // x로 만 비교
        if (x == pt.x) return 0;
        else if (x > pt.x) return 1;
        return -1;
    }
    /*
    public int CompareTo(object obj)
    {
        Point pt = (Point)obj;
        
        // x로 만 비교
        if (x == pt.x) return 0;
        else if (x > pt.x) return 1;
        return -1;
    }
    */
}

class Program
{
    public static void Main()
    {
        Point p1 = new Point(0, 0);
        Point p2 = new Point(1, 1);

        // C#에서 객체의 크기를 비교하는 일반적인 방법
        //p1 > p2;            // 방법 1. > 연산자 사용
        //                    //        사용자 타입인 경우 
                              //        연산자 재정의 함수로 제공해야 한다.
        //p1.CompareTo(p2);   // 방법 2. 크기를 비교하는 함수 제공

        Console.WriteLine(p1.CompareTo(p2));
    }
}









