﻿using System;
using System.Diagnostics; // Process 클래스
using System.Threading;

class Program
{
    public static void Main()
    {

    }
}