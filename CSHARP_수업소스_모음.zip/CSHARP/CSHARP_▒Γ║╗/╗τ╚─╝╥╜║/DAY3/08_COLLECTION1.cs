﻿using System;
using System.Collections;               // 1. non generic collections
using System.Collections.Specialized;   // 2. 타입에 특화된 collections
using System.Collections.Generic;       // 3. generic collections
using System.Collections.ObjectModel;   // 4. for Custom collections 
using System.Collections.Concurrent;    // 5. thread safe collections

class Program
{
    public static void Main()
    {
        //
        ArrayList c1 = new ArrayList();
        c1.Add("AA");

        //
        List<int> c2 = new List<int>();
        c2.Add(10);

        LinkedList<int> c3 = new LinkedList<int>();
        c3.AddFirst(10);

        // System.Collections.Specialized;
        StringDictionary d = new StringDictionary();

        // System.Collections.Concurrent
        ConcurrentStack<int> cs = new ConcurrentStack<int>();
        cs.Push(10);

    }
}
