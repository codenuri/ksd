﻿using System;
using System.Threading;

// TimeSpan : "특정 시각(2시 30분)" 또는 "시간의 기간(2시간 30분)"
// DateTime : 날짜, 시간을 관리

class Program
{
    public static void Main()
    {


    }
}
