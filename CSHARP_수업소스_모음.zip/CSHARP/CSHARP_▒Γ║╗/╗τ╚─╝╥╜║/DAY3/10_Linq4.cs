﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 지연된 실행, ToList(), 캡쳐된 변수

class Program
{
    public static void Main()
    {
        IList<int> list = new List<int> { 1, 2, 3 };

        var result = list.Select(n => n * 10);
        
        foreach (int n in result)
            Console.WriteLine(n);
    }
}




