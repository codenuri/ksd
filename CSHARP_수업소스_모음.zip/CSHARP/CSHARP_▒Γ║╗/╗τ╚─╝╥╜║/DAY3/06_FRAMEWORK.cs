﻿using System;
// CIL : 중간언어
// CLR : 가상 머신 + .net Framework
// CLS : Common Language Specification

// .net Framework
// mscorlib.dll

class Program
{
    public static void Main()
    {
        int n1 = 10;  // 결국 .net Framework 의 Int32입니다.
        Int32 n2 = 10;

    }
}

