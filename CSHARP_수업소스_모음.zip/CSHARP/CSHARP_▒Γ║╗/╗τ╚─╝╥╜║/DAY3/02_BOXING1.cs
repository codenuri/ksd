﻿using System;

// boxing / unboxing 개념

struct Point
{
    public int x;
    public int y;
    public Point(int a = 0, int b = 0) { x = a; y = b; }
}

class Program
{
    public static void Main()
    {
        // value type 이므로 stack 에 놓인다.
        Point p1 = new Point(0, 0);

        // object 는 class 이다. - reference type
        object o1 = p1; // p1의 복사본을 힙에 만든다.
                        // o1은 힙에 있는 복사본을 가리키게 된다.
                        // Boxing..

        //Point p2 = o1; // error
        Point p2 = (Point)o1; // ok .. UnBoxing
                              // 힙에 있던 복사본을 가지고
                              // 다시 스택객체 생성

        p1.x = 10;
        p1.y = 20;

        Console.WriteLine($"{p2.x} {p2.y}"); // 0, 0

        // 레퍼런스 타입은 힙에 있는 객체만 가리킬수 있다.
        // 스택객체를 가리키게하면 복사본이 힙에 생성되는 원리이다.
    }
}

