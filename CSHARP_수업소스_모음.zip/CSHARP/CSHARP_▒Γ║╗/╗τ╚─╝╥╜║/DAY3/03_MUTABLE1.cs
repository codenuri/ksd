﻿using System;
using System.Text;

// mutable vs immutable
// mutable : 객체의 상태를 변경가능 한것
// immutable : 객체의 상태를 변경할수 없는것

class Program
{
    public static void Main()
    {
        string s1 = "hello";
        s1[3] = 'A'; // error. string 은 immutable 합니다.

        StringBuilder s2 = new StringBuilder("hello");
        s2[3] = 'A'; // ok.. mutable 

        s1 = "world"; // new string("world")
        s1 = "aaa";   // new string("aaa") 
    }
}






