﻿using System;

// indexer : 객체를 배열처럼
class Sentense
{
    protected string[] words;
    public Sentense(string s) { words = s.Split(); }

    // 인덱서 : 객체를 배열 처럼 사용가능하게 하는 문법
    //         프라퍼티와 유사하게 만든다.
    //         프라퍼티 이름 자리에 "this[ ]"
    public string this[int idx]
    {
        set { words[idx] = value; }
        get { return words[idx]; }
    }
}
class Program
{
    public static void Main()
    {
        Sentense s = new Sentense("we are the world");
        s[0] = "i";

        Console.WriteLine(s[3]);  //world 

        s[3] = "frield";
        
    }
}



