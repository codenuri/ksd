﻿using System;
using System.Text;
using static System.Console;

class Edit
{
    string data = null;

    public string GetData()
    {
        data = ReadLine();
        return data;
    }
}


class Sample
{
    public static void Main()
    {
        Edit edit = new Edit();

        while(true)
        {
            string s = edit.GetData();
            WriteLine(s);
        }
    }
}

/*
class Edit
{
    StringBuilder data = null;

    public string GetData()
    {
        data = new StringBuilder();

        while( true )
        {
            var info = ReadKey(true);
            
            if ( info.Key == ConsoleKey.Enter )
            {
                break;
            }

            char c = info.KeyChar;

            if ( info.Key >= ConsoleKey.D0 && info.Key <= ConsoleKey.D9)
            {
                Write(c);
                data.Append(c);
            }
        }
        Console.WriteLine();
        return data.ToString();
    }
}
*/
