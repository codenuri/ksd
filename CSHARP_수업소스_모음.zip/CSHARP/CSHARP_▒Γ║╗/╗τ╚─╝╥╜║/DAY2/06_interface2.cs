﻿using System;

// 인터페이스의 메소드를 구현하는 방법

interface IShape
{
    void DrawImp();
}

class Rect : IShape
{
    // 1. 비 가상 함수로 재정의 
    //public void DrawImp() { Console.WriteLine("Rect DrawImp"); }

    // 2. 가상 함수로 재정의
    // override 아님.. virtual
    public virtual void DrawImp() { Console.WriteLine("Rect DrawImp"); }
}

class Program
{
    public static void Main()
    {
        IShape p = new Rect();
        p.DrawImp();
    }
}
