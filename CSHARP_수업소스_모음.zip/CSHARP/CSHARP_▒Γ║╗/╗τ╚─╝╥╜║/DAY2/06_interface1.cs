﻿using System;

// 추상 클래스 와 추상 메소드

// 추상 클래스 : 추상 메소드가 한개 이상인 것
// 의도 : 특정 함수를 반드시 만들라고 파생 클래스에게 지시하는것
/*
abstract class Shape
{
    public int color = 0;
    public abstract void DrawImp(); // 추상 메소드
                                    // abstract가 붙고 구현이 없다.
    public void Draw() { DrawImp(); }
}
*/
// 추상클래스 : 일부 멤버는 상속해 주고, 일부 함수는 만들라고 지시할때
// 인터페이스 : 만들어야 하는 규칙만 제공할때.
//              다른 멤버는 가질수 없다.
//              함수이름 앞에 abstract를 붙일 필요 없다.
interface Shape
{
   void DrawImp(); 
}

class Rect : Shape
{
    // 반드시 기반클래스의 추상 메소드를 재정의 해야만
    // Rect 객체를 만들수 있다.
    public void DrawImp() { Console.WriteLine("DrawImp"); }
}

class Program
{
    public static void Main()
    {
  //      Shape s = new Shape(); // error. 추상 클래스는 객체를 
                                // 만들수 없다.
        Shape p = new Rect();
    }
}