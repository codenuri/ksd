﻿using System;

// 상속과 생성자

class Base
{
    public Base()      { Console.WriteLine("Base()"); }
    public Base(int a) { Console.WriteLine("Base(int)"); }
}
class Derived : Base
{
    public Derived() : base() { Console.WriteLine("Derived()");  }

    // 기반 클래스의 디폴트가 아닌 다른 생성자를 호출하려면
    public Derived(int a) : base(a) { Console.WriteLine("Derived(int)"); }
}
class Animal
{
    protected Animal() { }
}
class Dog : Animal
{
}
class Program
{
    public static void Main()
    {
        Animal a = new Animal(); // error
        Dog    d = new Dog();    // ok

        //Derived d = new Derived(5);
    }
}


