﻿using System;

// 확장 메소드

class Car
{
    public void Go() { Console.WriteLine("Car Go"); }
}

// 기존 클래스에 새로운 멤버 함수를 추가하는 문법
public static class CarExtension
{
    public static void Stop(this Car c) // 인자는 "this 클래스이름"
    {                                   // 이어야 합니다.
        Console.WriteLine("Car Stop");

    }
}
class Extension
{
    public static void Main()
    {
        Car c = new Car();
        c.Go(); // Go( c )
        c.Stop();  // CarExtension.Stop(c);
    }
}