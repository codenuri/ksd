﻿using System;

// SOLID : SRP, OCP, LSP, ISP, DIP
// 개방 폐쇄의 법칙(Open Close Principle, OCP )

// 기능 확장에 열려있고(Open)
// 코드 수정에 닫혀 있어야(Close) 한다는 원칙(Principle)

// 약한 결합(loosely coupiling)  : 객체간의 관계가 약하게 결합된것
//                              서로 이름을 모르고 있다.
//                              확장성이 있다.

// 카메라 사용자와 카메라 제작자간의 규칙을 먼저 만든다.
// 규칙 : 모든 카메라는 아래 인터페이스로 부터 파생되어야 한다.
interface ICamera
{
    void Take();
//    void PlayMP3()
}

// 카메라가 없어도 사용자를 먼저 만들수 있다.

class People
{
    public void UseCamera(ICamera c) { c.Take();  }
}

class Camera : ICamera
{
    public void Take() { Console.WriteLine("take picture with Camera"); }
}
class HDCamera : ICamera
{
    public void Take() { Console.WriteLine("take picture with HDCamera"); }
}

class Coupling
{
    public static void Main()
    {
        People p = new People();
        Camera c = new Camera();
        p.UseCamera(c);

        HDCamera c2 = new HDCamera();
        p.UseCamera(c2); // ?
    }
}