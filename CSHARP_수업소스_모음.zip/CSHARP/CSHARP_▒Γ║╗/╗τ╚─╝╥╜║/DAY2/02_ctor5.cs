﻿using System;

// 주제 : 생성자와 가상함수 호출

class DM
{
    public DM()         { Console.WriteLine("DM()"); }
    public void UseDM() { Console.WriteLine("Use DM"); }
}
// C++ : 생성자에서는 가상함수가 동작하지 않습니다.
//       무조건 자신의 함수 호출

// C# :  생성자에서는 가상함수가 동작 합니다.
//       생성자에서 가상함수 호출시 초기화 되지 않은 객체를 사용하는
//       문제가 발생할수 있습니다.

class Base
{
    // 생성자와 가상함수 호출
    public Base() { foo(); }
    public virtual void foo() { Console.WriteLine("Base foo()"); }
}

class Derived : Base
{
    public DM dm =  new DM();

    public Derived() : base() { } //dm = new DM(); }

    public override void foo()
    {
        Console.WriteLine("Derived foo()");
        dm.UseDM();
    }
}


class Program
{
    public static void Main()
    {
        Derived d = new Derived();
    }
}