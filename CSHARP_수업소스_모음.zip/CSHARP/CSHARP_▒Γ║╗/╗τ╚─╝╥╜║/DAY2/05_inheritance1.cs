﻿using System;

// 주제 : 멤버 이름 충돌과 new
class Base
{
    public int value = 10;
}
class Derived : Base
{
    //public int value = 20; // 가능하지만 경고 발생.
    public new int value = 20; // 경고를 내지 말라는 것.

}
class Program
{
    public static void Main()
    {
        Derived d = new Derived();

        Console.WriteLine(d.value); // 20
        Console.WriteLine(((Base)d).value); // 10

    }
}