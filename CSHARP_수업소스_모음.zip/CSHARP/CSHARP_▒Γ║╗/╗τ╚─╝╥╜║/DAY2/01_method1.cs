﻿// cafe.naver.com/codenuri  게시판에서 2일차 사전소스 받으시면 됩니다.














using System;

// 주제 1. 인자 전달 방식
// 핵심 : out, ref 키워드

// 인자 전달 방법
// 1. 값 전달  : 복사 생성자
// 2. ref 전달 : 전달된 인자를 사용도 하고, 값도 담아 올때
// 3. out 전달 : 전달된 인자에 값을 담아오기만 할때
//               초기화 되지 않은 변수 사용가능

class Program
{
    public static void f1(int n) { n = 20; }
    public static void f2(ref int n)
    {
        int a = n; // ok
        n = 20;
    }
    public static void f3(out int n)
    {
        //int a = n; // error. n 은 쓸수만 읽고 읽을수는 없다.
        n = 20;
    }

    public static void Main()
    {
        int n1 = 10;
        int n2 = 10;
        int n3;

        f1(n1);     // n1 전달시 값을 전달하고 복사본 생성
        f2(ref n2); // n2 전달시 값이 아닌 메모리 정보 전달
                    // 복사본이 생성 안됨
        f3(out n3); // 초기화되지 않아도 상관없다.

        Console.WriteLine($"{n1}, {n2}, {n3}"); // 10, 20, 20

        //int n;
        //f2(ref n);
        //f3(out n);
    }
}