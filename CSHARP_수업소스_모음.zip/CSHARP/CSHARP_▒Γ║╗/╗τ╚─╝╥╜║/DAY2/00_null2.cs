﻿// cafe.naver.com/codenuri  게시판에서

// 2일차 사전소스 받으시면 됩니다.






using System;

// Nullable 타입, ?, ??

class Program
{

    public static bool IsNullable<T>(T obj)
    {
        var type = typeof(T);

        return Nullable.GetUnderlyingType(type) != null;
    }

    public static void Main()
    {
        int  n1 = 10;
        int? n2 = 10;

        Console.WriteLine(IsNullable(n1));
        Console.WriteLine(IsNullable(n2));
    }
}






