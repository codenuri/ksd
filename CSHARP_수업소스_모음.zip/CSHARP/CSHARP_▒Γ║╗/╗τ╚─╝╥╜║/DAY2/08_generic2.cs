﻿using System;

class Generic1
{
    //    public static void Foo(int n)    { }
    //    public static void Foo(object n) { }

    public static void Foo<T>(T n) { }

    public static void Main()
    {
        // template method 사용.
        //Foo<int>(0);
        Foo(0); // 0을 보고 T의 타입을 추론한다. - int
        
    }
}
