﻿using System;

// 식본문 메소드(expression-bodied method)

class Program
{
    //public static int square1(int x) { return x * x; }

       // 함수를 간략하게 만드는 문법
    public static int square1(int x) => x * x; 

    public static void Main()
    {
        Console.WriteLine(square1(3));
    }

}