﻿using System;

// SOLID : SRP, OCP, LSP, ISP, DIP
// 개방 폐쇄의 법칙(Open Close Principle, OCP )

// 기능 확장에 열려있고(Open)
// 코드 수정에 닫혀 있어야(Close) 한다는 원칙(Principle)

// 강한 결합(tightly coupiling)  : 객체간의 관계가 강하게 결합된것
//                              서로 이름을 알고 있다.
//                              확장성이 없다.
class Camera
{
    public void Take() { Console.WriteLine("take picture with Camera"); }
}

class HDCamera
{
    public void Take() { Console.WriteLine("take picture with HDCamera"); }
}

class People
{
    public void UseCamera(Camera c) { c.Take(); }
    public void UseCamera(HDCamera c) { c.Take(); }
}

class Coupling
{
    public static void Main()
    {
        People p = new People();
        Camera c = new Camera();
        p.UseCamera(c);

        HDCamera c2 = new HDCamera();
        p.UseCamera(c2); // ?
    }
}