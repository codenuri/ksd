﻿using System;

// 주제 : static 생성자
// 1. 인자를 가질수 없고, 오직 한개만 만들수 있다. 단, 한번만 호출된다.
// 2. 클래스의 static 멤버에 접근할때 호출.
// 3. 객체를 생성하면 호출.
class Car
{
    public int speed = 0;
    public static int count = 10;

    // static 생성자 : static 멤버를 초기화 하기 위한 생성자
    // 1. 객체를 만들지 않아도 static 멤버에 접근하려고 하면 호출
    // 2. 객체를 만들면 최초 1회만 호출
    static Car()
    {
        //count = 20;
        Console.WriteLine($"static Car() : {count}");
    }
    // 일반 생성자 : 객체를 만들때 마다 호출
    public Car()
    {
        Console.WriteLine($"Car() : {count}");
    }

}

class Program
{
    public static void Main()
    {
        Car.count = 10;  // static 멤버 사용
                        // static 생성자 호출

        Car c1 = new Car(); // 1. static 생성자
                            // 2. 일반 생성자
        Car c2 = new Car(); // 1. 일반 생성자 호출

        Console.WriteLine("Main");
    }
}