﻿using System;

// C# 4.0 부터 디폴트 파라미터 가능. 선택적 파라미터(Optional Parameter)라고 부름.
class Program
{
    public static void goo(int x = 0, int y = 0, int z = 0) { }

    public static void Main()
    {
        goo(1, 2, 3);
        goo(1, 2 );
        goo(1);

        // SetRect(x:0, y:0, widht:100, height:100);


        goo(x:1, y:2, z:3);
        goo(1, z: 3, y: 2);
        goo(y: 2);


        Base b = new Derived();
        // if ( 실행시간 조건 ) b = new Base();

        b.foo(); // 실행결과 예측해 보세요.
                 // Derived : 10
                 // b의메모리조사후객체결정.foo(10) 

        // 가상함수에서는 되도록이면 default 인자를 사용하지 마세요.!
    }
}


class Base
{
    public virtual void foo(int n = 10) { Console.WriteLine($"Base : {n}"); }
}
class Derived : Base
{
    public override void foo(int n = 20) { Console.WriteLine($"Derived : {n}"); }
}
