﻿using System;

// type parameter 제약
// int, string, template

class Generic3
{
    /*
     public static int Max( int a, int b)
    {
        return a.CompareTo(b) < 0 ? b : a;
        //   return a < b ? b : a;
    }
    public static string Max(string a, string b)
    {
        // a.CompareTo(b) : a < b 이면 음수, a>b 이면 양수
        return a.CompareTo(b) < 0 ? b : a;

        //return a < b ? b : a;
    }
    */
    /*
    public static T Max<T>(T a, T b)
    {
        // 이안에서 a, b는 object의 함수만 사용가능하다.
        // return a.CompareTo(b) < 0 ? b : a;

        // 해결책 1
        // 모든 비교 가능한 객체(CompareTo가 있는)는 
        // IComparable 인터페이스로부터
        // 파생 된다.
        IComparable x = a as IComparable;
        IComparable y = b as IComparable;
        return x.CompareTo(y) < 0 ? b : a;
    }
    */

    // 타입 제약이라는 문법( C++ concept )
    public static T Max<T>(T a, T b) where T : IComparable, new()
    {
        T p = new T();

        return a.CompareTo(b) < 0 ? b : a;
    }

    public static void Main()
    {
        Console.WriteLine(Max(10, 3));

        Console.WriteLine(Max("AAA", "BBB"));
    }
}



// where T : class
// where T : struct
// where T : new()
// where T : interface이름
// where T : base class 이름