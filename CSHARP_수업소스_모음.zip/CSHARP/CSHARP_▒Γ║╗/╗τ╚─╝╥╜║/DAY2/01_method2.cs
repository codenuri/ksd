﻿using System;

// 2. 인자 전달 방식과 참조 타입

class Point
{
    public int x = 0;
    public int y = 0;

    public Point(int a, int b) { x = a; y = b; }
}

class Program
{
    public static void f1(Point p)     { p.x = 10; }
    public static void f2(ref Point p) { p.x = 10; }

    public static void Main()
    {
        Point p1 = new Point(0, 0);

        //   f1(p1); // 1. 참조변수를 값으로 보낼때
        //p1이 가리키는 객체의 값을 변경할수 있다.

        //f2(ref p1);  // 2. 참조 변수를 ref로 보낼때.
        //p1이 가리키는 객체의 값을 변경할수 있다.

        f3(p1); // 참조 변수를 값으로 보내면
                // 1. 객체의 상태를 변경할수 있지만
                // 2. 새로운 객체를 만들수는 없다.

        f4(ref p1); // 참조 변수를 참조로 전달하기
                    // 참조 변수가 가리키는 객체의 정보가 아니라
                    // 참조 변수 자체의 정보 전달
                    // 1. 객체의 상태도 변경가능
                    // 2. 새로운 객체도 만들수 있다
        Console.WriteLine($"{p1.x}, {p1.y}");
    }

    public static void f3(Point p)     { p = new Point(1, 1); }
    public static void f4(ref Point p)
    {
        p = new Point(1, 1);
    }


}



