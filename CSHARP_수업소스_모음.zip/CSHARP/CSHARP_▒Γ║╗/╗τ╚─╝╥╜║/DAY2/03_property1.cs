﻿using System;

// 주제 : property
// ildasm 으로 확인
// 1. 사용시에는 필드처럼 보이지만 구현시에는 메서드 처럼 만드는 코드.

class Bike
{
    // 필드는 외부의 잘못된 사용으로 부터 막아야 한다. private
    private int gear = 0;

    // setter/getter
    //public void setGear(int n) { gear = n; }
    //public int  getGear() { return gear; }

    //public int a; // 필드
    //public void f(){}; // 함수(메소드)
    // Property : setter와 getter를 자동으로 만드는 문법

    // ildasm.exe 실행후.. 현재 실행파일 열어 보세요
    public int Gear
    {
        set { gear = value; }
        get { return gear; }
    }
}
class Program
{
    public static void Main()
    {
        Bike b = new Bike();
        b.Gear = 10;                // 쓰는 작업. set 호출
        Console.WriteLine(b.Gear);  // 읽는 작업. get 호출

        //b.gear = -10;
        //Console.WriteLine(b.gear);

    }
}

