﻿using System;


// Point<T>   : Open Type
// Point<int> : Close Type
class Point<T>
{
    public T x;
    public T y;

    // default(T) : T가 참조 타입이면 null,  primitive 이면 0
    // C++ : T a = T()
    public Point(T a = default(T), T b = default(T)) { x = a; y = b; }

}

class Generic1
{
    public static void Main()
    {
        Point<int> p1 = new Point<int>(1, 1);
    }
}
