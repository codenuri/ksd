﻿using System;

// 함수 재정의(override)
class Base
{
    //public void Foo() { Console.WriteLine("Base Foo"); }  // 1

    // virtual : 함수를 dynamic binding 하게 해달라는 지시어.
    public virtual void Foo() { Console.WriteLine("Base Foo"); }  // 1
}
class Derived : Base
{
    // 동일이름이 있으므로 경고
    //public void Foo() { Console.WriteLine("Derived Foo"); }

    // 경고를 없애려면 new 사용 - 함수 오버라이드
    //public new void Foo() { Console.WriteLine("Derived Foo"); } // 2

    // Foo 가 가상일때
    // 1. new 사용 : 가상함수 재정의 아님. 새로운 함수를 만든것
    //public new void Foo() { Console.WriteLine("Derived Foo"); } // 2

    // 2. override 사용 : 가상함수 재정의
    public override void Foo() { Console.WriteLine("Derived Foo"); } // 2
} 

class Program
{
    public static void Main()
    {
        Base    b = new Derived();
        Derived d = new Derived();

        // if ( 사용자입력 == 1 ) b = new Base();
        // 컴파일러는 b가 실제로어느 객체를 가리키는지 알수 있을까요 ?
        b.foo(); // 
        d.foo(); // "Derived foo"
    }
}


// 함수 바인딩 
// b.foo()를 어디와 연결할 것인가 ?
// 1. static binding : 컴파일러가 컴파일 시간에 결정하는 것
//                      참조 타입밖에 알수 없다.
//                      Base foo 호출
// early binding - 빠르다.  C++, C#


// 2. dynamic binding : 컴파일러는 b가 가리키는 메모리를 조사하는
//                      기계어 코드 생성
//                      실행시 조사후 호출
//                      Derived foo 호출
// late binding  - 느려다. 논리적이다.
//                          java, objective-c, swift
//                      C++과 C#의 virtual function
