﻿using System;

// Multicast Delegate, reference type, immutable
delegate void FP(int a);

class Program
{
    public static void Foo(int a) { Console.WriteLine($"Foo : {a}"); }
    public static void Goo(int a) { Console.WriteLine($"Goo : {a}"); }
    public void Hoo(int a) { Console.WriteLine($"Hoo : {a}"); }

    public static void Main()
    {
        // 1. 델리게이트에는 여러개 함수 등록 가능.
        FP f = Foo;         // static 메소드 등록 방법 1. 함수이름
        f += Program.Goo;   // static 메소드 등록 방법 2. 클래스이름.함수이름

        //f += Hoo;          // error. static이 아니므로 객체가 필요하다.
        Program p = new Program();
        f += p.Hoo;          // ok. 인스턴스 메소드는 객체.함수이름

        f(10); // f.Invoke(10).. 결국 3개 함수 호출


        // 2. 델리게이트는 reference type
        FP f1 = Foo; // FP f1 = new FP(Foo)
        FP f2 = f1;

        if (f1 == f2)
            Console.WriteLine("same");// same
        else
            Console.WriteLine("not same");

        // 3. 델리게이트는 immutable 하다.
        f2 += Goo; // 기존 델리게이트가 아니라
                   // 새로운 델리게이트 객체가 생성되어서
                   // f2가 가리키게됩니다.

        if (f1 == f2)
            Console.WriteLine("same");
        else
            Console.WriteLine("not same"); // !!!!

        f1(10); // 어떻게 될까요 ?  1. Foo 만 호출
                //                 2. Foo, Goo 모두 호출
    }
}








