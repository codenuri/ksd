﻿using System;

// event handling #1. 

class Button
{
    public delegate void Handler(); // class Handler : MulticastDelegate

    public Handler hander = null;

    public void Press()
    {
        // 여기서 일을 하게 되면 모든 버튼은 동일한 일을 하게된다.
        // 버튼이 눌린사실을 외부에 알려야 한다.
        // 등록된 함수를 호출한다.

        //if (handler != null)
        //    Handler();

        //handler ? ();
        handler?.Invoke();
    }
}

class Program
{
    public static void OnClick() { Console.WriteLine("Button Click"); }
    public static void Main()
    {
        Button b1 = new Button();
        Button b2 = new Button();

        b1.hander = OnClick; // 버튼을 누를때 호출할 핸들러 등록.

        b1.Press();
    }
}
