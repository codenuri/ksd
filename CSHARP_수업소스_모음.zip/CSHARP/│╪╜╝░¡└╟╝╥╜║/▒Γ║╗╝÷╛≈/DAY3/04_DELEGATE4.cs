﻿using System;


// csc 04_DELEGATE4.cs   빌드후..

// ildasm 04_DELEGATE4.exe 로 열어 보세요


delegate void HANDLER();

class Button
{
    // Click 을 외부에서 접근가능, +=, -=, = 모두 사용가능.
    // 단점 : 실수로 = 사용하면, 기존 등록된 함수 모두 제거됨
    //public HANDLER Click = null;

    
    // 외부에서 직접 Click 접근 안됨
    // add_Click(), remove_Click()함수가 자동 생성됨.
    // 함수를 통해서만 접근 가능.
    public event HANDLER Click = null;

    public void Press()
    {
        Click?.Invoke();
    }
}

class Program
{
    public static void OnClick1() { Console.WriteLine("Button Click"); }
    public static void OnClick2() { Console.WriteLine("Button Click2"); }
    public static void OnClick3() { Console.WriteLine("Button Click3"); }

    public static void Main()
    {
        Button b = new Button();

        b.Click += OnClick1;    // Click 이 event라면
                                // += 은 add_Click() 함수 호출
                                // -= 은 remove_Click() 호출
        b.Click += OnClick2;
        //b.Click = OnClick3; // += 을 하려고 했는데, 실수 했다.
                                // event 라면 error

        b.Press();
    }
}