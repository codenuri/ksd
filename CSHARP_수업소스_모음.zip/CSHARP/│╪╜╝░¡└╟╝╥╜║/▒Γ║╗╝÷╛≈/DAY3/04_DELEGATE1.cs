﻿using System;

// 함수를 보관하는 데이타 타입 : delegate
delegate void FP(int a);
/*
// 위 코드를 보고 컴파일러는 아래 코드를 생성합니다.
class FP : MulticastDelegate
{
    // invoke() 함수 추가.
};
*/


class Program
{
    public static void Foo(int a) { }

    public static void Main()
    {
        int n = 10;     // 10은 int 타입
        double d = 3.4; // 3.4 는 double 타입

        //? f = Foo; // Foo 는 함수.. 함수를 보관할수 있는
                    // 데이타 타입이 필요 하다.

        FP fp = new FP(Foo); // 정확한 표현
        fp.Invoke(10); // 이순간 Foo(10) 이 호출됩니다.

        // 델리게이트를 사용하는 간단한 표현
        FP fp2 = Foo;  // new FP(Foo)의 의미와 동일
        fp2.Invoke(10);
        fp2(10); // 위와 동일.


        //string s1 = new string("AA");
        //string s2 = "AA";
    }
}



