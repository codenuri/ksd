﻿using System;

class Animal { }
class Dog : Animal { }


// Dog가 Animal로 변환된다면
// X<Dog> 가 X<Animal> 로 변환될수 있게 하는것이 좋습니다
// "공변성(covariance)를 지원한다고 표현 합니다."
// out 지시어..
// C#의 Func 는 공변성을 지원 합니다.
delegate TResult MyFunc<out TResult>();

class Delegate6   
{
    public static Animal F1() { return null; }
    public static Dog F2()    { return null; }

    public static void Main()
    {
        MyFunc<Animal> d1 = F1; // 반환값이 Animal  인 함수
        MyFunc<Dog>    d2 = F2; // 반환값이 Dog 인 함수

        MyFunc<Animal> d3 = d1; // ok. d3와 d1은 같은 타입이다.
        MyFunc<Animal> d4 = d2; // ???

        Animal ret = d4();  // ? 채워 보세요. 
                            // 이때 d4가 반드시 Animal 을 리턴해야만 할까 ?
                            // Dog를 리턴하면 안될까 ?

      


        Action<Animal> a1 = F3; // 인자가 Animal
        Action<Dog> a2 = F4;    // 인자가 Dog

        Action<Dog> a3 = a2; // ok.. 동일 타입.
        Action<Dog> a4 = a1; // ??
       
        // Dog가 인자인 함수가 필요하면
        // Animal인 인자를 사용해도 된다.
        // 반변성
        // delegate void Action<in T> (T arg); // 반변성을지원하는
        //                                      Action
        
    }

    public static void F3(Animal a) { }
    public static void F4(Dog a) { }
}

