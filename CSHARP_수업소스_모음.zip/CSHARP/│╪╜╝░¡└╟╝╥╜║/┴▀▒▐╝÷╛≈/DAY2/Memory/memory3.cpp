#include <iostream>
#include <memory>
#include <string>
using namespace std;

struct People
{
	string name;
	People(string s) : name(s) {}
	~People() { cout << name << " �ı�" << endl; }

	shared_ptr<People> bestFriend;
};

int main()
{
	shared_ptr<People> sp1(new People("KIM")); // ���� 1
	shared_ptr<People> sp2(new People("LEE")); // ���� 1

	// cycle reference �߻�.
	sp1->bestFriend = sp2;
	sp2->bestFriend = sp1;

	cout << "--------------------------" << endl;
}







