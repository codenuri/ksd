#include <iostream>
using namespace std;

int main()
{
	// C
	int* p1 = (int*)malloc(100);
	free(p1);

	// C++
	int* p2 = new int[25];
	delete[] p2;
}
