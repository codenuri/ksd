﻿using System;
using System.IO;
using static System.Console;

class Object : IDisposable
{
    public FileStream fs = null;
    public Object(string name) { fs = new FileStream(name, FileMode.CreateNew); }
}

class Program
{
    static void Main(string[] args)
    {
        Object o = new Object("a.txt");
    
    }
}

