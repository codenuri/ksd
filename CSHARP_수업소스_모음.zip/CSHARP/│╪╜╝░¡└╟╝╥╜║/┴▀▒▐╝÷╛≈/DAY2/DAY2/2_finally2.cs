﻿using System;
using System.IO;
using static System.Console;

class Test
{
    /*
    static void foo()
    {
        FileStream fs = new FileStream("a.txt", FileMode.Create);

        if ( 다른 작업 실패)
        {
            fs.Dispose();
            return;
        }
        fs.Dispose(); // 닫지 않아도 결국 닫히게 되지만
                        // 명시적으로 Dispose 하는 것이 좋다.
    }
 */
    /*
       static void foo()
       {
           FileStream fs = new FileStream("a.txt", FileMode.Create);

           try
           {
               // 다른 작업 수행
           }
           finally
           {
               if (fs != null)
                   fs.Dispose();
           }        
       }
    */
    static void foo()
    {
        // 아래 코드는 위와 동일한 코드를 생성해 줍니다.
        using (FileStream fs = new FileStream("a.txt", FileMode.Create))
        {
            // fs 를 사용해서 작업
        }        
    }
 
    static void Main()
    {
        foo();
    }
}