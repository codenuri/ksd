﻿using System;
using System.Collections.Generic;
using static System.Console;

// 다른 객체를 포함한후
// 기능을 추가 : Decorator 패턴
// 인터페이스(함수이름)의 변경 : Adapter 패턴.

//  객체 Adapter(포함) class Adapter(상속)

class Stack //: List<int>
{
    public List<int> st = null; // 원본 저장소

    public Stack( List<int> s) { st = s; }
    // 원본저장소의 인터페이스를 변경할 함수들
    public void Push( int a)
    {
        st.Add(a);
    }
    public int Pop()
    {
        int n = st.Count - 1;
        int temp = st[n];
        st.RemoveAt(n);
        return temp;
    }
}

class Program
{
    public static void Main()
    {
        List<int> s = new List<int>();

        s.Add(10);
        s.Add(20);

        // List s 를 스택 처럼 사용하고 싶다.
        Stack st = new Stack(s);
        st.Push(30);
        st.Push(40);

        WriteLine(st.Pop());
        WriteLine(st.Pop());
        WriteLine(st.Pop());
    }
}


