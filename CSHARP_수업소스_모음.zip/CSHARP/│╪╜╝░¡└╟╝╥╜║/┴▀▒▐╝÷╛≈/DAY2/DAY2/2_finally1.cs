﻿using System;
using System.IO;
using static System.Console;

// catch : 예외 발생시만 실행
// finally : try 블럭을 벗어날때 항상 실행
class Test
{
    static int foo()
    {
        int temp = 10;
        try
        {
            //....
            //int n = 0;
            //int s = 10 / n;
            return temp; // 스택에 리턴값을 잠시 보관하고
                         // finally 수행후. 리턴값 꺼내서 반환
        }  
        /*
        catch( Exception e)
        {
            WriteLine("예외 발생");
        }
        */
        finally
        {
            temp = 20;
            WriteLine("이 구문은 try 를 벗어날때 항상 실행됩니다.");
        }
        return  temp;
    }
    static void Main()
    {
        WriteLine(foo()); // 10
    }
}


