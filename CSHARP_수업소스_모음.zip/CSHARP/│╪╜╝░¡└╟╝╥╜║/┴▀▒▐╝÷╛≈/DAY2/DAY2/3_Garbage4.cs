﻿using System;
using static System.Console;

// mark and sweep : 쓰레기 수집기가 수행시
//                  root로 부터 접근할수 없는 객체를 mark 하고
//                  청소(sweep) 하는것

// 단점 :1. 메모리 전체를 청소하기에는 시간이 많이 걸린다.
//       2. 메모리 파편화를 막아야 한다.

// Generation
// 오랜 동안 살아온 사람 => 빨리 죽는다.
// 짧게 살아온 사람      => 더 오래 산다.

// 오랜 동안 살아온 변수 => 더 오래 산다.
// 짧게 살아온 변수      => 빨리 죽는다.

// 되도록이면 사용자가 쓰레기 수집을 하지 말자
// 단, 24시간마다 한번씩 실행되는 프로그램
//  작업후에는 "모든 세대 쓰레기 수집" 하는 것이 좋다.

class Object
{
    public string name = null;
    public Object(string n) { name = n; }
}

class Program
{
    static void Main(string[] args)
    {
        Object oa = new Object("A"); // 0세대 힙에 놓인다.
        Object ob = new Object("B"); // 0세대 힙에 놓인다.

        WriteLine(GC.GetGeneration(oa)); // 0
        WriteLine(GC.GetGeneration(ob)); // 0

        oa = null;  
        GC.Collect(); // 0,1,2 세대 모두에 대해 쓰레기를 수집한다.

        WriteLine(GC.GetGeneration(ob)); // 1

        GC.Collect(1); // 0세대 힙을 수집한다.
        WriteLine(GC.GetGeneration(ob)); // 1

        WriteLine("Main End");
    }
}



