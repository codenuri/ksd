﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using static System.Console;

class People
{
    public string name;
    public int age;
    public bool isChild;

    public People bestFriend = null;
    public People(string n, int a)
    {
        name = n;
        age = a;
        isChild = (age < 13);
    }
}

class Program
{
    public static void Main()
    {
        People p1 = new People("KIM", 14);
        People p2 = new People("LEE", 12);
        p1.bestFriend = p2;


    }

}