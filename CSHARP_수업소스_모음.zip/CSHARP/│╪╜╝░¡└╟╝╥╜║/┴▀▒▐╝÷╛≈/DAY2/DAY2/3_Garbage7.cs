﻿using System;
using static System.Console;

// weak
class Object
{
    public string name = null;
    public Object(string n) { name = n; }
    ~Object() { WriteLine("{0} Destroy", name); }

    public void Go() { WriteLine("Go"); }
}

class Program
{
    static void Main(string[] args)
    {
        Object o1 = new Object("A");
        Object o2 = o1;
           
        o1 = null;

        GC.Collect();
        GC.WaitForPendingFinalizers();

        if (o1 != null) o1.Go();
        if (o2 != null) o2.Go();
        WriteLine("-----------------------");
    }
}


