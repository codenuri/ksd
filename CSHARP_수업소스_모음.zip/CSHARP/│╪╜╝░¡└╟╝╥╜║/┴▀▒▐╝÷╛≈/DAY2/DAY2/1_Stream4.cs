﻿
using System;
using static System.Console;

// 기능추가대상객체 와 기능추가 객체(Decorator)는 공통의 
// 기반 클래스(인터페이스 또는 추상 클래스)가 있어야 한다.
interface IFire
{
    void Fire();
}

// 새로운 기능 추가 객체를 만들려면
// IFire 인터페이스를 구현하면 된다.(Fire() 함수 필요)


class Fighter : IFire
{
    public void Fire() { WriteLine("Fire Missile"); }
}


class LeftMissile : IFire
{
    public IFire fg = null; // 포함
    public LeftMissile(IFire f) { fg = f; }
    public void Fire()
    {
        fg.Fire(); // 원래 기능 수행
        WriteLine("Fire Left Missile"); // 새로운 기능 수행.
    }
}

class RightMissile : IFire
{
    public IFire fg = null; // 포함
    public RightMissile(IFire f) { fg = f; }
    public void Fire()
    {
        fg.Fire(); // 원래 기능 수행
        WriteLine("Fire Right Missile"); // 새로운 기능 수행.
    }
}

class Program
{
    static void Main()
    {
        Fighter f = new Fighter();
        f.Fire();

        // 아이템 획득
        RightMissile rm = new RightMissile(f);
        rm.Fire();

        LeftMissile lm = new LeftMissile(rm);
        lm.Fire();

    }
}


