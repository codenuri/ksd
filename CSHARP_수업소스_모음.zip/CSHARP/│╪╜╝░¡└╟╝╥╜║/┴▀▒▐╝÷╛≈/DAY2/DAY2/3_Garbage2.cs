﻿using System;
using static System.Console;

// GC.Collect()

class Object
{
    public string name = null;

    public Object(string n) { name = n; }

    ~Object() { WriteLine("{0} Destroy", name); }
}

class Program
{
    public static void foo()
    {
        Object o = new Object("Object ");
    }
    static void Main(string[] args)
    {
        foo();

        GC.Collect();  // 사용하지 않는 메모리를 제거해 달라
                       // 쓰레기 수집기 동작
        GC.WaitForPendingFinalizers(); // 소멸자(Finallizer) 실행대기

        WriteLine("Main End");
    }
}
