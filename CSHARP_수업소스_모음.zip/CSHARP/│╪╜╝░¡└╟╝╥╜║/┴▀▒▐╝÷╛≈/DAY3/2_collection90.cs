﻿using System;
using System.Collections;
using System.Collections.Generic;
using static System.Console;

// 주제 9. BitArray

class Program
{
    public static void Main()
    {
        List<bool> st = new List<bool>();
        st.Add(true);
        st.Add(false);
    

    }
}