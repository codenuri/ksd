﻿using System;
using System.Collections;
using System.Collections.Generic;
using static System.Console;

// 사용자 정의 Collection

class Program
{
    public static void Main()
    {
        List<int> s = new List<int>();
    }
}