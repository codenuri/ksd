﻿using System;
using System.Dynamic;
using static System.Console;

class Program
{
    public static int Add1(int a, int b)
    {
        return a + b;
    }

    public static void Main()
    {
        WriteLine(Add1(1, 2));

    }
}