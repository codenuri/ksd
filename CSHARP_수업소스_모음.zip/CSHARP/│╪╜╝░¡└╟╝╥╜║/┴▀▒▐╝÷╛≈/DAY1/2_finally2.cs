﻿using System;
using System.IO;
using static System.Console;

class Test
{
    static void foo()
    {
        FileStream fs = new FileStream("a.txt", FileMode.Create);
        fs.Dispose();
    }
 
    static void Main()
    {
        foo();
    }
}