﻿using System;
using System.Threading.Tasks;
using static System.Console;

// 주제 6. 예외를 다시 던지기2
// "catch 후 예외를 다시 던지는 것 보다는 예외 필터가 좋다."

class Server
{
    public void Connect()
    {
        throw new TimeoutException(); 
    }
}

class Program
{
    // 3번을 시도하고 안되면 예외 전달
    static void foo()
    {
        int retryCount = 0;
        bool bSuccess = false;

        Server wc = new Server();

        while (bSuccess == false)
        {
            try
            {
                wc.Connect();
            }
            catch (TimeoutException e) when ( retryCount++<3)
            {
                WriteLine("one more try");
            }

            /*
            catch (TimeoutException e)
            {
                if (retryCount++ < 3)
                    WriteLine("one more try");
                else
                    throw;
            }
            */
        }
    }

    static void Main()
    {
        try
        {
            foo();
        }
        catch (Exception e) 
        {
            Console.WriteLine(e.StackTrace);
        }
    }
}