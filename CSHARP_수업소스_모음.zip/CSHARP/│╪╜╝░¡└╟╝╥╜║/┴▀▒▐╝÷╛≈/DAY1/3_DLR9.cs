﻿using System;
using System.Collections.Generic;
using static System.Console;

// 방문자의 인터페이스
interface IShapeVisitor
{
    void visit(Shape s);
    void visit(Point p);
    void visit(Circle c);
}
// 방문의 대상의 인터페이스
interface IAcceptor
{
    void Acceptor(IShapeVisitor v);
}



// IronPython : Python의 .net 버전.
class Shape : IAcceptor
{
    public virtual void Acceptor(IShapeVisitor v)
    {
        v.visit(this);
    }
    public virtual void Draw() { WriteLine("Shape Draw"); }
}
class Point : Shape
{
    public override void Acceptor(IShapeVisitor v)
    {
        v.visit(this);
    }
    public int x = 0;
    public int y = 0;
    public Point(int a = 0, int b = 0) { x = a; y = b; }
    public override void Draw() { WriteLine("Point Draw"); }
}
class Circle : Shape
{
    public override void Acceptor(IShapeVisitor v)
    {
        v.visit(this);
    }
    public int radius = 0;
    public Circle(int r = 0) { radius = r; }
    public override void Draw() { WriteLine("Circle Draw"); }
}

class Sheet : IAcceptor
{
    List<Shape> st = new List<Shape>();

    public void Acceptor(IShapeVisitor v)
    {
        // 모든 요소를 방문자에게 전달한다.
        foreach (Shape s in st)
        {

            // 각 도형에 다시 방문자를 보낸다.
            s.Acceptor(v);
        }

    }

    public void Append(Shape s) { st.Add(s); }

}

// 모든 도형을 이동하는 방문자
class ShapeMoveVisitor : IShapeVisitor
{
    public void visit(Circle c) { WriteLine("Circle 이동"); }
    public void visit(Point p) { WriteLine("Point 이동"); }
    public void visit(Shape s) { WriteLine("Shape 이동"); }
}





class Program
{
    public static void Main()
    {
        Sheet s = new Sheet();
        s.Append(new Point(10, 10));
        s.Append(new Circle(5));

        // 모든 도형을 이동하는 방문자를 사용한다.
        ShapeMoveVisitor smv = new ShapeMoveVisitor();
        s.Acceptor(smv);

        // 모든 도형의 색상을 변경하는 방문자
        //  ChangeColorVisitor ccv;
        //  s.Acceptor(ccv);
    }
}

