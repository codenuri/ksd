﻿using System;
using static System.Console;

// 주제 2. try ~ catch
// 
class Program
{
    static void Main()
    {
        string s = "0";
        try
        {
            int n = int.Parse(s);

            int n2 = 10 / n; // 0으로 나누는 예외

            WriteLine(n);
        }
        
        catch( FormatException e)
        {
            WriteLine("숫자로 변환할수 없음.");
        }
     
        catch (Exception e)  // C#  의 모든 예외를 잡는다.
        {
            WriteLine("Exception");
        }
        catch
        {
            WriteLine("Exception");
        }

        WriteLine("프로그램은 계속 수행될수 있음");
    }
}