﻿using System;
using System.Runtime.Serialization;
using static System.Console;

// 주제 9. 사용자 정의 예외 만들기
// 1. 예외를 발생하기 전에 객체의 상태를 조사할수 있으면 좋다.
// 2. 예외가 없는 버전의 함수도 고려할 필요가 있다.

class MyException : Exception { }

class WebTools
{
    // 객체의 유효성을 조사하는 함수를 같이 제공해라
    public bool IsValid()
    {
        // Work 가능하지 조사
        return false;
    }
    public void Work()
    {
        // 실패시 예외 전달
        throw new MyException();
    }
    public bool TryWork()
    {
        if (IsValid() == false)
            return false;
        try
        {
            Work();
        }
        catch(Exception e)
        {
            return false;
        }
        return true;
    }
}
class Program
{
    static void Main()
    {
        WebTools wt = new WebTools();
        if ( wt.IsValid() == false )
        {
            //....
        }
        wt.Work();
    }
}