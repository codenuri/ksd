﻿using System;
using System.Collections.Generic;
using static System.Console;

// List가 있는데 Stack 필요하다.
// List를 Stack 처럼 보이게 하면 된다.

class Program
{
    public static void Main()
    {
        List<int> s = new List<int>();

        s.Add(10);
        s.Add(20);

    }
}


