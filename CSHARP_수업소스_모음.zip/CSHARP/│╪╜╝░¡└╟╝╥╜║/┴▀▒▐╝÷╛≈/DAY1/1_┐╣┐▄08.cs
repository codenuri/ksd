﻿using System;
using System.Runtime.Serialization;
using static System.Console;

// 주제 8. 사용자 정의 예외 만들기

// 1. Exception 파생 클래스로 만들어야 한다.
[Serializable]
class MyException : Exception
{
    // 생성자를 4개 만들어야 한다.
    public MyException() { }
    public MyException(string s) : base(s) { }
    public MyException(string s, Exception e) : base(s, e) { }
    public MyException(SerializationInfo info,
        StreamingContext ctx) : base(info, ctx)
    { }
}
class Server
{
    public void Connect()
    {
        //throw new MyException("접속실패예외");

        try
        {
            int n = int.Parse("ipaddr");
        }
        catch(FormatException e)
        {
            // 내부적으로 발생한 예외를 포함해서 전달
            throw new MyException("접속실패", e);
        }
    }
}

class Program
{
    static void Main()
    {
        Server s = new Server();
        try
        {
            s.Connect();
        }
        catch (MyException e)
        {
         //   WriteLine(e.Message);
            WriteLine("{0}, {1}", e.Message, e.InnerException.Message);
        }
    }
}