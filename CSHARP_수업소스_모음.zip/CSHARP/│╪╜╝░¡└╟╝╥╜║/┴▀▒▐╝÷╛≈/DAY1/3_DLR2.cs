﻿using System;
using System.Dynamic;
using static System.Console;

// var vs dynamic
// var     : 우변으로 좌변 타입 결정
// dynamic : 실행시간에 타입 조사
class Program
{
    public static void Main()
    {
        var     v1 = "hello";// 컴파일시 : string   실행시 : string
        dynamic v2 = "hello";// 컴파일시 : dynamic  실행시 : string

        // 1, 2는 각각 어떻게 될까요 ?
        int n1 = v1; // 1. 컴파일 에러
        int n2 = v2; // 2. 실행시간 예외
    }
}