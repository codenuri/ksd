﻿using System;
using System.Net;
using static System.Console;

// 주제 4. 예외 필터
// 

class Program
{
    static void Main()
    {
        string s = null;
        WebClient wc = new WebClient();
        int a;
        try
        {
           
            s = wc.DownloadString("http://wwww.naver.com");
            WriteLine(s);
        }
        // 예외 필터..
        catch (WebException e) when(e.Status == 
                    WebExceptionStatus.NameResolutionFailure)
        {
            WriteLine("URL 잘못");
        }
        catch(WebException e)
        {
            WriteLine("다른 문제");
        }

        /*
        catch( WebException e)
        {
            if (e.Status == WebExceptionStatus.NameResolutionFailure)
                WriteLine("URL이 잘못되었습니다.");
            else
                WriteLine("다른 문제");
        }
        */

        wc.Dispose();
    }
}