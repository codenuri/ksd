﻿using System;
using System.Threading.Tasks;
using static System.Console;

// 주제 7. 예외 필터를 사용한 Logging ( 예외 필터에 false 넣기)

class Server
{
    public void Connect()
    {
        throw new TimeoutException();
    }
}

class Program
{
    static void foo()
    {
        Server wc = new Server();

        try
        {
            wc.Connect();
        }
        catch (Exception e) when(Logging(e))
        {
        }        
    }
    // catch 문 수행없이 logging 만 하고 외부에 바로 전달.
    static bool Logging(Exception e)
    {
        WriteLine(e.Message);
        return false;
    }

    static void Main()
    {
        try
        {
            foo();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.StackTrace);
        }
    }
}