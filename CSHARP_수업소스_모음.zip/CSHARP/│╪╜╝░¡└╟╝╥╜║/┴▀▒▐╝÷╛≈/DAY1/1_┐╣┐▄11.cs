﻿using System;
using static System.Console;

struct Point
{
    public int x;
    public int y;
}

class TwoPoint
{
    Point[] arr = new Point[2];

    public TwoPoint(string s1, string s2, string s3, string s4)
    {
        arr[0].x = int.Parse(s1);
        arr[0].y = int.Parse(s2);
        arr[1].x = int.Parse(s3);
        arr[1].y = int.Parse(s4);
    }
    /*
    public void assign(string s1, string s2, string s3, string s4)
    {
        arr[0].x = int.Parse(s1);
        arr[0].y = int.Parse(s2);
        arr[1].x = int.Parse(s3);
        arr[1].y = int.Parse(s4);
    }
    */
    public void assign(string s1, string s2, string s3, string s4)
    {
        // 복사본으로 작업을 하고
        Point[] temp = new Point[2];

        temp[0].x = int.Parse(s1);
        temp[0].y = int.Parse(s2);
        temp[1].x = int.Parse(s3);
        temp[1].y = int.Parse(s4);

        // 성공하면 원본과 교체 - copy and swap 이라는 개념.
        arr = temp;
    }
    public void Dump()
    {
        WriteLine("{0}, {1}, {2}, {3}", arr[0].x, arr[0].y, arr[1].x, arr[1].y);
    }
}

class Test
{
    static void Main()
    {
        TwoPoint tp = new TwoPoint("0", "0", "1", "1");
        tp.Dump();

        try
        {
            tp.assign("10", "10", "a", "11");
        }
        catch { }

        tp.Dump(); 
    }
}