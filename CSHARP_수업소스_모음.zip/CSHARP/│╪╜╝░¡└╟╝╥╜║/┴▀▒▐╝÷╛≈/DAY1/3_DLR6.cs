﻿using System;
using System.Collections;
using System.Collections.Generic;
using static System.Console;

class Animal
{
    public virtual void Fight(Animal a) { WriteLine("Animal vs Animal"); }
    public virtual void Fight(Dog a) { WriteLine("Animal vs Dog"); }
    public virtual void Fight(Cat a) { WriteLine("Animal vs Cat"); }
}
class Dog : Animal
{
    public override void Fight(Animal a) { WriteLine("Dog vs Animal"); }
    public override void Fight(Dog a) { WriteLine("Dog vs Dog"); }
    public override void Fight(Cat a) { WriteLine("Dog vs Cat"); }
}
class Cat : Animal
{
    public override void Fight(Animal a) { WriteLine("Cat vs Animal"); }
    public override void Fight(Dog a) { WriteLine("Cat vs Dog"); }
    public override void Fight(Cat a) { WriteLine("Cat vs Cat"); }
}

class Program
{
    public static void Main()
    {
        Animal[] arr = new Animal[10];

        arr[0] = new Dog();
        arr[1] = new Cat();

        arr[0].Fight((dynamic)arr[1]); // Dog vs Cat
        arr[1].Fight((dynamic)arr[0]); // Cat vs Dog
    }
}

// Single Dispatch : 객체에 따라서만 분배 된다(인자를 조사하지 못한다.)
// animal참조.Fight(animal참조)
// 실제객체조사.Fight(실제객체조사 하지 않고 무조건animal)

// Multiple Dispatch : 객체에 뿐아니라 인자에 따라서도  분배 된다
//                  (인자를 조사해서 호출)

