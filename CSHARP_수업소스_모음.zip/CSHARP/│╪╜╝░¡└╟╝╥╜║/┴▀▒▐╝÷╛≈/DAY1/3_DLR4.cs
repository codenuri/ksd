﻿using System;
using System.Dynamic;
using static System.Console;

// DynamicObject

class Dog
{
    public void Cry() { WriteLine("Dog Cry"); }
}

class Program
{
    public static void Main()
    {
        dynamic a = new Dog();
        a.Cry();
    }
}