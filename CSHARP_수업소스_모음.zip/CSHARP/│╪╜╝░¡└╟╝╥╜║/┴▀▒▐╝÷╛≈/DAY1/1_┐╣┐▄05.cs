﻿using System;
using static System.Console;

// 주제 5. 예외를 다시 던지기( throw e, throw, 예외필터)

class Server
{
    public void Connect()
    {
        throw new TimeoutException();
    }
}

class Program
{
    static void foo()
    {
        Server wc = new Server();
        try
        {
            wc.Connect();
        }
        catch ( TimeoutException e) 
        {
            // 어떤 처리를 하고.. 다시 외부로 예외를 던지고 싶다.
           // throw e;  // 1
           throw;      // 2 좋은 코드.. 이유는
                        //  stackTrace 시에 원래 예외 정보 포함
        }
    }

    static void Main()
    {
        try
        {
            foo();
        }
        catch(Exception e)
        {
            WriteLine(e.StackTrace);
        }
    }
}