﻿using System;
using static System.Console;

// 주제 1. 함수가 오류를 반환하는 방법
// 예외   : 성능저하, 반드시 처리해야 한다.
// 반환값 : 반드시 처리할 필요는 없다. 함수 모양이 복잡해진다.
//  
//권장 : 예측 가능한 중요하지 않은 실패 => 반환값 사용
//                 심각한 오류 => 예외 사용        
class Program
{
    static void Main()
    {
        int n = 0;

        //n = int.Parse("a");
        bool b = int.TryParse("a", out n);

        WriteLine(n);
    }
}


