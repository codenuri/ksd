class zzz
{
    public static void Main()
    {
        System.Console.WriteLine("hi");
    }
}
