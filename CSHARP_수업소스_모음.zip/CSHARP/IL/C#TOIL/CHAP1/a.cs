using System;

delegate int FP(int a, int b);

class zzz
{
    public static int foo(int a, int b) => a+ b;

    public static void Main()
    {
        FP f = foo;
        
        System.Console.WriteLine("hi");

        var z = new zzz();
    }
}