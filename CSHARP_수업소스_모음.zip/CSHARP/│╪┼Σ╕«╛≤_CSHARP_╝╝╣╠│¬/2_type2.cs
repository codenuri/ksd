﻿using System;

// 핵심 5. equality

//                  참조 타입               값타입

// ==               참조 비교               기본적으로 제공 안됨
//                                          연산자 재정의로 제공가능

// Equals 함수       기본적으로 참조 비교     메모리 자체를 비교
//                   재정의를 통해서 변경가능 재정의로 변경가능


class Point   // reference type
{

    public int x = 0;
    public int y = 0;

    public Point(int a, int b) { x = a; y = b; }

    public override bool Equals(object obj)
    {
        Point pt = (Point)obj;
        return pt.x == x && pt.y == y;
    }

    public static bool operator ==(Point p1, Point p2)
    {
        Console.WriteLine("==");

        return p1.x == p2.x && p1.y == p2.y;
    }
    public static bool operator !=(Point p1, Point p2)
    {
        return p1.x != p2.x || p1.y != p2.y;
    }
}

class Program
{
    public static void Main()
    {


        Point p1 = new Point(1, 1);
        Point p2 = new Point(1, 1);

        // 방법 1. 상등 연산자 == 
        // 참조 변수가 가지고 있는 참조값(주소)로 비교
        Console.WriteLine(p1 == p2);

        // 방법 2. Equals 멤버 함수 사용
        // 레퍼런스 타입 : 참조 변수가 가지고 있는 참조값(주소)로 비교
        // 가상 함수 이므로 재정의를 통해서 정책 변경 가능.
        Console.WriteLine(p1.Equals(p2));
    }
}



/*
struct Point   // value type
{
public int x;
public int y;

public Point(int a, int b) { x = a; y = b; }

// 연산자 재정의 : static method 로 구현
// == 를 제공한 경우 반드시 != 도 같이 제공해야 한다.
public static bool operator==(Point p1, Point p2)
{
    return p1.x == p2.x && p1.y == p2.y;
}
public static bool operator !=(Point p1, Point p2)
{
    return p1.x != p2.x || p1.y != p2.y;
}



public override bool Equals(object obj)
{
    Console.WriteLine("Equals");
    Point pt = (Point)obj;
    return pt.x == x && pt.y == y;
}

}

class Program
{
public static void Main()
{
    Point p1 = new Point(1, 1);
    Point p2 = new Point(1, 1);

    // value 타입 일때..
    // 방법 1. 상등 연산자 == 
    // 기본 적으로 == 연산이 안됨..
    // 사용자가 연산자 재정의 가능.
    Console.WriteLine(p1 == p2);

    // 방법 2. Equals 멤버 함수 사용
    // value type : 메모리 자체의 내용을 비교(bitwise compare)
    // 가상 함수 이므로 재정의를 통해서 정책 변경 가능.
    Console.WriteLine(p1.Equals(p2));
}
}
*/
