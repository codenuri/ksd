﻿using System;

// Equals 함수
// 1. object 가 제공하는 멤버 함수 - Equals(object obj)
// 2. IEquatable<T> 인터페이스가 제공하는 함수 - 
/*
interface IEquatable<T>
{
    bool Equals(T obj);
}
*/
struct Point : IEquatable<Point>
{
    public int x;
    public int y;
    public Point(int a = 0, int b = 0) { x = a; y = b; }

    // Equals 는 object 클래스가 가진 가상함수 입니다
    // 정책을 변경하려면 Equals 가상함수를 재정의 하면 됩니다.
    /*
    public override bool Equals(object obj)
    {
        Point pt = (Point)obj;
        return x == pt.x;
        //
    }
    */
    public override bool Equals(Point obj)
    {
        return x == obj.x;

    }

}

class Program
{
    public static void Main()
    {
        Point p1 = new Point(0, 0);
        Point p2 = new Point(0, 1);

        if (p1.Equals(p2))
        {
            Console.WriteLine("Same");
        }
        else
            Console.WriteLine("not Same");

    }
}