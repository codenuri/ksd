﻿using System;

// 핵심 1. 모든 것은 객체이다.

class Program
{
    public static void Main()
    {
        // 1. 
        string s = 10.ToString();
        Console.WriteLine(s);


        // 2. 문자열을 int 변환
        string s = "10";
        int n = int.Parse(s); // string => int
                              // int의  static  method
        Console.WriteLine(n);

        // 3. 문자열이 아닌 정수 입력 받기.
        // scanf("%d", &a); // 55 입력

        // 문자열로 입력받고, 그것을 다시 정수로 변환해서 사용.
        int n2 = int.Parse(Console.ReadLine());
        Console.WriteLine(n2);
    }
}