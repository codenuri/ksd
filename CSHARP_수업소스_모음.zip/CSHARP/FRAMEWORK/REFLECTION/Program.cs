﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REFLECTION
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            Type t1 = a.GetType();
            Type t2 = typeof(int);
            Type t3 = Type.GetType("System.Int32");

            Console.WriteLine($"{t1.FullName}");
            Console.WriteLine($"{t2.FullName}");
            Console.WriteLine($"{t3.FullName}");

            var v = t1.GetInterfaces();

            foreach( var i in v)
            {
                Console.WriteLine($"{i.FullName}");
            }
     
        }
    }
}
