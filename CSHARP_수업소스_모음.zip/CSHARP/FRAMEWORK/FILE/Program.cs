﻿using System;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        FileStream fs = File.Create("a.txt");
        fs.Dispose();

        File.Delete("b.txt");

        File.Copy("a.txt", "b.txt");

        FileInfo fi = new FileInfo("c.txt");

        Console.ReadKey();

        fi.Create();

    }
}
