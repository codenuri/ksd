﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

// Task<TResult> 클래스 사용법
// 

class Program
{
    public static void Foo()
    {
        Console.WriteLine($"{Thread.CurrentThread.IsThreadPoolThread}");
    }
    static void Main()
    {
//        Enumerable.Range(1, 1000);

        // 2 ~ 3,000,000 사이의 난수의 갯수를 구하는 코드!! 좋은 예제
        Task<int> primeNumberTask = Task.Run(() => Enumerable.Range(2, 3000000).Count(n => Enumerable.Range(2, (int)Math.Sqrt(n) - 1).All(i => n % i > 0)));

        Console.WriteLine("Task running...");
        Console.WriteLine("The answer is " + primeNumberTask.Result);
    }
}
