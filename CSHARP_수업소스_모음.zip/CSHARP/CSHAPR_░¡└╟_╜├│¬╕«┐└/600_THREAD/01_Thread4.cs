﻿using System;
using System.Diagnostics;
using System.Threading;

// 핵심 
// 1. Thread 우선 순위
// 2. Process의 우선순위 클래스와 같이 설명 할것.

class Program
{
    static void Main()
    {
        Process p = Process.GetCurrentProcess();

        Console.WriteLine($"{p.PriorityClass}");

        Thread t = Thread.CurrentThread;

        Console.WriteLine($"{t.Priority}");

    }
}
