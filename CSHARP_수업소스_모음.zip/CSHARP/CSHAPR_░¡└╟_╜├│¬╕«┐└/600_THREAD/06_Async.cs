﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    /*
    // 동기 버전
    public static int GetPrimesCount(int start, int count)
    {
        // 소스의 갯수를 반환하는 함수
        return ParallelEnumerable.Range(start, count).Count(n =>Enumerable.Range(2, (int)Math.Sqrt(n) - 1).All(i => n % i > 0));
    }
    public static void DisplayPrimeCounts()
    {
        for (int i = 0; i < 10; i++)
            Console.WriteLine(GetPrimesCount(i * 1000000 + 2, 1000000) +" primes between " + (i * 1000000) + " and " + ((i + 1) * 1000000 - 1));

        Console.WriteLine("Done!");
    }
    */
    // 비동기 버전
    public static Task<int> GetPrimesCountAsync(int start, int count)
    {
        // return Task.Run(() => Enumerable.Range(2, 3000000).Count(n => Enumerable.Range(2, (int)Math.Sqrt(n) - 1).All(i => n % i > 0)));
        
        return Task.Run(() => ParallelEnumerable.Range(start, count).Count(n => Enumerable.Range(2, (int)Math.Sqrt(n) - 1).All(i => n % i > 0)));
    }
    /*
    // 방법 1. 
    public static void DisplayPrimeCounts()
    {
        for (int i = 0; i < 10; i++)
        {
            int temp = i;
            var awaiter = GetPrimesCountAsync(i * 1000000 + 2, 1000000).GetAwaiter();
            awaiter.OnCompleted(() => Console.WriteLine(awaiter.GetResult() + " primes between... " + temp.ToString() ));
        }
        Console.WriteLine("Done");
    }
    */
    // 방법 2. 
    public static void DisplayPrimeCountsFrom(int i)
    {
        //var awaiter = GetPrimesCountAsync(i * 1000000 + 2, 1000000).GetAwaiter();

        Task<int> task = GetPrimesCountAsync(i * 1000000 + 2, 1000000);

        var awaiter = task.GetAwaiter();

        awaiter.OnCompleted(() =>
        {
            int temp = i;
            Console.WriteLine(awaiter.GetResult() + " primes between..." + temp.ToString() + ", " + Thread.CurrentThread.ManagedThreadId.ToString() );

            if (++i < 10) DisplayPrimeCountsFrom(i);
            else Console.WriteLine("Done");
        });
    }

    public static void DisplayPrimeCounts()
    {
        DisplayPrimeCountsFrom(0);
    }
    static void Main()
    {
        DisplayPrimeCounts();

        Console.WriteLine($"Main : {Thread.CurrentThread.ManagedThreadId}");

        Console.ReadLine();
    }

}

