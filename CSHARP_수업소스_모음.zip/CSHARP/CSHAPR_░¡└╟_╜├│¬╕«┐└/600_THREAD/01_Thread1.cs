﻿using System;
using System.Threading;

// 핵심
// 1. Thread 를 생성하는 방법
// 2. Thread 함수 모양 : ThreadStart , ParameterizedThreadStart
class Program
{
    public static void Foo()
    {
        for (int i = 0; i < 1000; i++)
            Console.Write("Foo");
    }
    public static void Goo(object obj)
    {
        for (int i = 0; i < 1000; i++)
            Console.Write("Goo");
    } 
    public static void Hoo(string msg)
    {
        for (int i = 0; i < 1000; i++)
            Console.Write("Hoo");
    }
    static void Main()
    {
        Foo();

        Thread t1 = new Thread(Foo);
        t1.Start();


        Thread t2 = new Thread(Goo);
        t2.Start("hello");


        //Thread t3 = new Thread(Hoo); // error

        Thread t3 = new Thread( () => Hoo("hello") ); // ok
        t3.Start();

        Console.WriteLine("Continue Main");
        Console.Read();
    }
}
