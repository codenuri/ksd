﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

// Task 객체의 연속작업을 연결하는 예제
// 

class Program
{
    public static int Foo()
    {
        Console.WriteLine($"Foo : {Thread.CurrentThread.ManagedThreadId}, {Thread.CurrentThread.IsThreadPoolThread}");

        int n = Enumerable.Range(2, 3000000).Count(n => Enumerable.Range(2, (int)Math.Sqrt(n) - 1).All(i => n % i > 0));

        return n;
    }
    static void Main()
    {
        Task<int> primeNumberTask = Task.Run(Foo);

        primeNumberTask.ContinueWith( antecedent => { Console.WriteLine($"ContinueWidth : {Thread.CurrentThread.ManagedThreadId}, {Thread.CurrentThread.IsThreadPoolThread}"); });


        var awaiter = primeNumberTask.GetAwaiter();

        awaiter.OnCompleted(() =>
        {
            Console.WriteLine($"OnCompleted : {Thread.CurrentThread.ManagedThreadId}, {Thread.CurrentThread.IsThreadPoolThread}");
            int result = awaiter.GetResult();
            Console.WriteLine(result); // Writes result
        });

        Console.WriteLine($"Main : {Thread.CurrentThread.ManagedThreadId}, {Thread.CurrentThread.IsThreadPoolThread}");
        Console.ReadLine();
    }
}
