﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    public static async Task<T> DelayResult<T>(T result, TimeSpan delay)
    {
        await Task.Delay(delay);
        return result;
    }

    static void Main()
    {
        Task<int> t = DelayResult(100, new TimeSpan(0, 0, 3));

        Console.WriteLine("Main");
        Console.WriteLine(t.Result);

        Console.ReadLine();
    }

}

