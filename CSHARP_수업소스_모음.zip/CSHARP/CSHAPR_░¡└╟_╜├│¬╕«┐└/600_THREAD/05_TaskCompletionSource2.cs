﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    public static Task Delay(int milliseconds)
    {
        var tcs = new TaskCompletionSource<object>();
        var timer = new System.Timers.Timer(milliseconds) { AutoReset = false };
        timer.Elapsed += delegate { timer.Dispose(); tcs.SetResult(null); };
        timer.Start();
        return tcs.Task;
    }

    static void Foo()
    {
        Console.WriteLine($"Foo : {Thread.CurrentThread.ManagedThreadId}, {Thread.CurrentThread.IsThreadPoolThread}");
        Console.WriteLine($"Foo : {Thread.CurrentThread.ManagedThreadId}, {Thread.CurrentThread.IsThreadPoolThread}");
        Console.WriteLine($"Foo : {Thread.CurrentThread.ManagedThreadId}, {Thread.CurrentThread.IsThreadPoolThread}");
        Console.WriteLine($"Foo : {Thread.CurrentThread.ManagedThreadId}, {Thread.CurrentThread.IsThreadPoolThread}");
        Console.WriteLine($"Foo : {Thread.CurrentThread.ManagedThreadId}, {Thread.CurrentThread.IsThreadPoolThread}");
        Console.ReadKey();
    }
    static void Main()
    {
        //Task.Delay(1000).GetAwaiter().OnCompleted(Foo);
        Delay(1000).GetAwaiter().OnCompleted(Foo);

        Console.WriteLine($"Main : {Thread.CurrentThread.ManagedThreadId}, {Thread.CurrentThread.IsThreadPoolThread}");

        for( int i = 0; i< 3000;i++)
        {
            //Thread.Sleep(10);
            Console.WriteLine(i);
        }
        Console.WriteLine($"Main : {Thread.CurrentThread.ManagedThreadId}, {Thread.CurrentThread.IsThreadPoolThread}");

        Console.ReadLine();
    }
}
