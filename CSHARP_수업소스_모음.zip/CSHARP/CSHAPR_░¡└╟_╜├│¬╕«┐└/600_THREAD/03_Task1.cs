﻿using System;
using System.Threading;
using System.Threading.Tasks;

// Task 클래스 사용법
// 

class Program
{
    public static void Foo()
    {
        Console.WriteLine($"{Thread.CurrentThread.IsThreadPoolThread}");
    }
    static void Main()
    {
//        Task t1 = new Task(Foo);
//        t1.Start();
           
        // 아래처럼 실행하면 풀 스레드가 아님.
//        Task t2 = Task.Factory.StartNew(Foo, TaskCreationOptions.LongRunning);
        

        Task t3 = Task.Run(Foo);

        Console.ReadLine();
    }
}
