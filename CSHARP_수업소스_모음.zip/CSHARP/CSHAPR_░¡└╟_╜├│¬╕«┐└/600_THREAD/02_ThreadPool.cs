﻿using System;
using System.Diagnostics;
using System.Threading;

// 핵심 
// 1. CThreadPool 클래스 사용하기
// 2. Pool Thread 의 특징
//    A. Name 속성을 전달할수 없다. 
//    B. 항상 

class Program
{
    static void Main()
    {
        ThreadPool.QueueUserWorkItem();
    }
}
