﻿using System;
using System.Threading;

// 핵심 
// Thread 클래스 의 멤버 함수와 속성
class Program
{
    public static void Foo()
    {
        for (int i = 0; i < 1000; i++)
            Console.Write("Foo");
    }
    static void Main()
    {
        Thread t1 = new Thread(Foo);

        t1.Name = "WORKER1";

        Console.WriteLine($"{t1.Name}, {t1.ThreadState}, {t1.IsThreadPoolThread}, {t1.IsAlive}, {t1.ManagedThreadId}");

        var state = t1.ThreadState;

        t1.Start();

        t1.Join();
    }
}
