﻿using System;
using System.Threading;

// 핵심 
// 1. isBackground 속성 변경
// 2. background thread vs foreground thread 차이점
// 3. try ~ finally 블럭
// 4. join(3000) 으로 시간 부여
class Program
{
    public static void Foo()
    {
        for (int i = 0; i < 1000; i++)
        {
            Console.Write("Foo");
        }

    }
    static void Main()
    {
        Thread t1 = new Thread(Foo);

        t1.IsBackground = true;

        t1.Start();

        Console.WriteLine("Main Finish");

    }
}
