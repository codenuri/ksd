﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

// Task 객체의 연속작업을 연결하는 예제
// 

class Program
{

    /*
    public static int Foo()
    {
        var tcs = new TaskCompletionSource<int>();

        new Thread(() => { Thread.Sleep(5000); tcs.SetResult(42); }) { IsBackground = true }.Start();


        Task<int> task = tcs.Task; // Our "slave" task.
        Console.WriteLine(task.Result); // 42

    }
    Task<TResult> Run<TResult>(Func<TResult> function)
        {
            var tcs = new TaskCompletionSource<TResult>();
            new Thread(() =>
            {
            }
            try { tcs.SetResult(function()); }
            catch (Exception ex) { tcs.SetException(ex); }
        }).Start();
        return tcs.Task;
    }
    static void Main()
    {
        Task<int> task = Run(() => { Thread.Sleep(5000); return 42; });
    }
    */
    static void Main()
    {
        var tcs = new TaskCompletionSource<int>();

        //new Thread(() => { Thread.Sleep(5000); tcs.SetResult(42); }) { IsBackground = true }.Start();

        Task<int> task = tcs.Task; // Our "slave" task.

        Console.WriteLine(task.Result); // 42
    }
}
