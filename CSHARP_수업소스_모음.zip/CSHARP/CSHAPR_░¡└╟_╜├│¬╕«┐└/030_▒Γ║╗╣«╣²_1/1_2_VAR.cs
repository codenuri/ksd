﻿using System;

// 1. var 변수
// 2. 초기화 되지 않은 변수
class Program
{
    static void Main()
    {
        int    n1 = 10;
        double d1 = 3.4;

        var n2 = 10;
        var d2 = 3.4;

        int n3;
        Console.WriteLine(n3); // error

        
    }
}
