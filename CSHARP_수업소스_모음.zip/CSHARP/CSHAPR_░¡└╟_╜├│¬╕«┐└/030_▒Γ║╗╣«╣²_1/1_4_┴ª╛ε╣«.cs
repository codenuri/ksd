﻿using System;

// is 에 대한 설명

class Program
{
    static void Main()
    {
        int n1 = 10;

        if (n1 is object )
        {
            Console.WriteLine("object type");
        }

        if ( n1 is int )
        {
            Console.WriteLine("int type");
        }
        
        if ( n1 is 10 )
        {
            Console.WriteLine("10");
        }
    }
}
