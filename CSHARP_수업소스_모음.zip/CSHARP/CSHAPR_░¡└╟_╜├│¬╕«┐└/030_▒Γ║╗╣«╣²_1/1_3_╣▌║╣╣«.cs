﻿using System;

// 1. while 문, do~while(), for
// 2. foreach
// for vs foreach 의 성능 조사할것!

class Program
{
    static void Main()
    {
        int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

        // 전통적인 for 문
        for (int i = 0; i < 10; i++)
            Console.WriteLine(arr[i]);

        // C#의 foreach 구문
        foreach( var n in arr )
            Console.WriteLine(n);

        // 다차원 배열 - 이부분에 핵심을 맞출것!
        int[,] arr2 = { { 1, 2 }, { 3, 4 }, { 5, 6 } };

        foreach (var n in arr2)
            Console.WriteLine(n);

    }
}
