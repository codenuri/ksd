﻿using System;

// 2진수 표기법, 자리수 표기법


class Program
{
    static void Main()
    {
        // C# 7.0
        int n1 = 0b101010;  // 2진수 표기법 ( binary literal )
        int n2 = 1_000_000; // 

        int n3 = 0x0F0F_1234;
        int n4 = 0b0000_1111_0000_1010;

        Console.WriteLine($"{n1}, {n2}, {n3}, {n4}");
    }
}
