﻿using System;
using System.IO;
using static System.Console;

// 핵심. Console 출력을 redirect 하는 방법

class Program
{
    static void Main()
    {
        StreamWriter sw = new StreamWriter("d:\\a.txt");

        Console.SetOut(sw);

        Console.WriteLine("Hello, world");

        sw.Dispose();
    }
}
