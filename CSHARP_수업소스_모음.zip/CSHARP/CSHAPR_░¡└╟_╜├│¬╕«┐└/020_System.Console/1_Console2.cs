﻿using System;
using static System.Console;

// 핵심. System.Console 클래스 포맷터
// 화면 출력시 다양한 포맷을 지정하는 방식을 보여 줄것.

class Program
{
    static void Main()
    {
        int n1 = 100;
        Console.WriteLine($"{n1:0, -2}");

    }
}
