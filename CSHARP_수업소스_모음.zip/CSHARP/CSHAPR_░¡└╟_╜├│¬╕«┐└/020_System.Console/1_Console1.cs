﻿using System;
using static System.Console;

// 핵심 : System.Console 클래스를 사용하는 기본 방법
class Program
{
    static void Main()
    {        
        // 1. 완전한 표기법
        System.Console.WriteLine("Hello World!");

        // 2. using System;
        Console.WriteLine("Hello World!");

        // 3. using static Console; - C# 6.0
        WriteLine("Hello World");

        // 4. Write vs WriteLine


        int n1 = 10, n2 = 20, n3 = 30;

        // 5. 변수값을 출력하는 방법, 문자열
        Console.WriteLine(n1);
        Console.WriteLine("{0}, {1}, {2}", n1, n2, n3);
        Console.WriteLine($"{n1}, {"n2"}, {{n3}}"); // C# 6.0
        Console.WriteLine(@"C:\AAA\BBB\CCC");
        Console.WriteLine($@"C:\AAA\BBB\{n1}");
        Console.WriteLine(@$"C:\AAA\BBB\{n1}");

        string s1 = $"{n1}, {n2}, {n3}";        // C# 6.0


    }
}
