﻿using System;
using System.IO;
using static System.Console;

// 표준입력 : Read(), ReadKey(), ReadLine()
//            Console.In / Console.out

class Program
{
    static void Main()
    {
        // # read
        int n1 = Console.Read();
        int n2 = Console.Read();
        Console.WriteLine($"{(char)n1}, {(char)n2}");

        // # direct input from keyboard
        ConsoleKeyInfo ki = Console.ReadKey(true);
        Console.WriteLine($"{ki.KeyChar}");

        // # flush
        while (Console.In.Peek() != -1)
            Console.Read();

        string s1 = Console.ReadLine();
        Console.WriteLine(s1);
    }
}
