﻿using System;
using System.IO;
using static System.Console;

// 핵심. Console 의 다양한 멤버 함수를 활용하는 예제를 보여 줄것

class Program
{
    static void Main()
    {
        Console.BackgroundColor = ConsoleColor.Red;
        Console.Clear();
    }
}
