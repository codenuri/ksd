﻿using System;
using System.IO;
using static System.Console;

// 정수 또는 실수를 입력 받는 방법
// 문자열 => 정수 변환이 필요하다는 점. 강조
// 문자열 => 정수로 변경하는 모든 방법 정리. 장단점도 정리           
class Program
{
    static void Main()
    {
        string s = Console.ReadLine();

        //int v = Convert.ToInt32(s);
        //double v = Convert.ToDouble(s);

        int v = int.Parse(s);

        Console.WriteLine($"{v}");
    }
}
