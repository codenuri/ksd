﻿using System;
using System.Threading;

// delegate 변환
//delegate void F1();
//delegate void F2();

class Program
{
    static void Main()
    {
        int value = 10;

        ThreadStart act = () => { Console.WriteLine($"{value}"); ++value; };

        act();
        
        Thread t1 = new Thread(act);
        Thread t2 = new Thread(act);

        t1.Start();
        t2.Start();

        t1.Join();
        t2.Join();

        Console.WriteLine($"Main : {value}");
    }
}
