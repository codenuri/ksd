﻿using System;

class Point
{
    public int x;
    public int y;

    public Point(int a, int b) { x = a; y = b; }
}
class Program
{
    public static void Main()
    {
        // C# 8.0 : Target Typed new

        Point p1 = new Point(1, 2);
        //Point p2 = new ( 1, 2);

        Point[] pa1 = { new Point(1, 2), new Point(2, 2) };
        Point[] pa2 = { new (1, 2),      new (2, 2) };

        Point[] ps = { new (1, 4), new (3, 2), new (9, 5) };


    string[] names = { "Dirk", "Jane", "James", "Albert", "Sally" };

        foreach (var name in names)
        {
            // do something
        }

        // C# 8.0. Range
        foreach (var name in names[1..4])
        { 
            
        }

        Index idx = new Index(1, true);
        Index idx2 = 1;
        Index idx3 = ^1;

        Console.WriteLine(names[idx]);

        Range range = new Range(idx2, idx3);
        //Range range = new Range(1, 4);
        //Range range = 1..4;        

        foreach (var name in names[range])
        {
            Console.WriteLine(name);
        }


    }
}
