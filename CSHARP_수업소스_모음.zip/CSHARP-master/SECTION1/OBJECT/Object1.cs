﻿using System;

class Car // : System.Object
{

}

class Program
{
    static void Main(string[] args)
    {  
        Car c = new Car();

        c.ToString();

        //Car.Equals(null, null);
       
    }
}
