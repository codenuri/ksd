﻿using System;

class Program
{
    /*
    public static int Square(int a)
    {
        return a * a;
    }
    */
    public static int Square(int a) => a * a;

    public static void Main()
    {
        Console.WriteLine( Square(3) );
    }
}
