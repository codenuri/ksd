﻿using System;

class Program
{
    public static void Main()
    {
        // int : 타입
        // 10  : int 타입의 객체
        10.ToString();
        //int.Parse();

        //3.4.CompareTo
        int n = 10; // System.Int32

        string s1 = "AAA";
        String s2 = "AAA";
        System.String s3 = "AAA";

        System.Int32 n3 = 10;
        Int32 n4 = 10;
    }
}
