﻿using System;

class Program
{
    public static void Main()
    {
        
        int n1;// = 10;
        n1 = 20;
        Console.WriteLine(n1);

        double n2 = 10;
        var n3 = n2; //
      
    }
}