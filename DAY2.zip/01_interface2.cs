﻿using System;

interface IShape
{
    void Draw();
}

class Rect : IShape
{
}

class Program
{
    public static void Main()
    {
        IShape p = new Rect();
        p.Draw();
    }
}
