﻿using System;
using System.Collections;               // 1. non generic collections
using System.Collections.Specialized;   // 2. 타입에 특화된 collections
using System.Collections.Generic;       // 3. generic collections
using System.Collections.ObjectModel;   // 4. for Custom collections 
using System.Collections.Concurrent;    // 5. thread safe collections

class Program
{
    public static void Main()
    {
        Dictionary<string, string> d = new Dictionary<string, string>();

        d["mon"] = "월요일";

        d.Add("sun", "일요일");

        Console.WriteLine(d["mon"]);

    }
}
