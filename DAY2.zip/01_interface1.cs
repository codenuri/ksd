﻿using System;

// 추상 클래스 와 추상 메소드
abstract class Shape
{
    public int color = 0;
    public abstract void Draw(); 
}
class Rect : Shape
{
    public void Draw() { Console.WriteLine("Draw Rect"); }
}

class Program
{
    public static void Main()
    {
        Shape s = new Shape();
        Rect  p = new Rect();
    }
}