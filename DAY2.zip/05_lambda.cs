﻿using System;

class Program
{
    public static void Main()
    {
        int v1 = 10;

        //Func<int, int, int> plus = (int x, int y) => { return x + y; };
    }
}