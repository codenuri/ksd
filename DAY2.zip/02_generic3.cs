﻿using System;

// type parameter 제약
// int, string, template

class Generic3
{
     public static int Max( int a, int b)
    {
        return a < b ? b : a;
    }
  
    public static void Main()
    {
        Console.WriteLine(Max(10, 3));
    }
}



// where T : class
// where T : struct
// where T : new()
// where T : interface이름
// where T : base class 이름