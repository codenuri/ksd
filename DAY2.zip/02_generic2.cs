﻿using System;

class Program
{
    public static void Foo(int n)    { }

    public static void Main()
    {
        Foo(10);
    }
}
