﻿using System;
using System.Reflection;

// 타입 정보 얻기
class Program
{
    public static void Main()
    {
        int n = 10;  

        Type t = n.GetType();


    }
}












