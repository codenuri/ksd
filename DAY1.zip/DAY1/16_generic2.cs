﻿using System;

class Generic1
{
    //    public static void Foo(int n)    { }
    //    public static void Foo(object n) { }

    public static void Foo<T>(T n) { }

    public static void Main()
    {
        // template method 사용.
        
    }
}
