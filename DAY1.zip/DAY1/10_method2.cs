﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Point
{
    public int x;
    public int y;

    public Point(int a, int b) { x = a; y = b; }
}

class Program
{
    public static void F1(Point p) { p.x = 10; }
    public static void Main()
    {
        Point p = new Point(1, 2);
        F1(p);

        Console.WriteLine(p.x);
    }
}