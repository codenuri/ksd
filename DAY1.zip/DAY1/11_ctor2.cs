﻿using System;

// 주제 : static 생성자
// 1. 인자를 가질수 없고, 오직 한개만 만들수 있다. 단, 한번만 호출된다.
// 2. 클래스의 static 멤버에 접근할때 호출.
// 3. 객체를 생성하면 호출.
class Car
{
    public int speed = 0;
    public static int count = 10;

    Car()
    {
        count = 20;
        Console.WriteLine($"static Car() : {count}");
    }
}

class Program
{
    public static void Main()
    {
        
    }
}