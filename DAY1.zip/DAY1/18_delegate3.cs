﻿using System;

// event handling

class Button
{
    public void Click()
    {
    
    }
}

class Delegate3
{
    public static void Main()
    {
        Button b = new Button();
        b.Click();
    }
}