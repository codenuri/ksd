﻿using System;

// 안전한 코드를 만들기 위한 문법들

class Program
{
    public static void Main()
    {
        int n;
        Console.WriteLine(n);  

        int n1 = int.MaxValue;
        int n2 = n1 + 1; 
    }
}