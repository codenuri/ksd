﻿using System;

// 모든 타입은 object로 부터 파생 된다.
// int의 원리
/*
struct int : object 
{
    //......
}
*/

class Program
{
    public static void Foo(object o)
    {

    }

    public static void Main()
    {
        Foo(10);
    }
}