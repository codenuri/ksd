﻿using System;

// 핵심 5. 캐스팅
// is, as, 캐스트

class Animal { };

class Dog : Animal
{
    public void Cry() { Console.WriteLine("Dog Cry"); }
}

class Program
{
    public static void Main()
    {
        // 1. 기반 클래스 타입의 참조로 파생 클래스를 가리킬수 있다.
        Animal a = new Dog();



    }
}



