﻿using System;

// 핵심 5. value_type vs reference type



struct SPoint    
{
    public int x;
    public int y;
}
class CPoint    
{
    public int x;
    public int y;
}
class Program
{
    public static void Main()
    {
        // 아래 2줄의 메모리 그림을 항상 생각하세요
        SPoint sp1 = new SPoint();
        CPoint cp1 = new CPoint();



    }
}



// value type     : numeric primitive type, struct, enum
// reference type : string, array, class, interface, delegate