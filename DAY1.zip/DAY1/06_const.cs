﻿using System;

// 핵심 4. 컴파일 시간 상수 vs 실행시간 상수

class Program
{
    public static int n1 = 10;
    public static int n2 = 10;
    public static int n3 = 10;



    public static void Main()
    {

    }
}


