﻿using System;

class Program
{
    public static void Main()
    {
        int n1 = 3;
        double d = n1;

        int n2 = d; 
       
    }
}