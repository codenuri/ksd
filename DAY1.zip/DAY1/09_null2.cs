﻿using System;

// Nullable 타입, ?, ??

class Program
{
    public static int Foo() { return -1; }

    public static void Main()
    {
        //int ret = Foo();
    }
}


