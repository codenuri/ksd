﻿using System;

// boxing / unboxing 개념

struct Point
{
    public int x;
    public int y;
    public Point(int a = 0, int b = 0) { x = a; y = b; }
}

class Program
{
    public static void Main()
    {
        // value type 이므로 stack 에 놓인다.
        Point p1 = new Point(0, 0);

        object o1 = p1; 
    }
}