﻿using System;

// 핵심 3. 키워드와 식별자

class int
{
    public void show() { Console.WriteLine("int.show()"); }
}
class where { }

class Program
{
    public static void Main()
    {
        int n;

        int n2 = new int();
        n2.show();

    }

}

