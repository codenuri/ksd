﻿// using

class Program
{
    static void Main(string[] args)
    {
        System.Console.WriteLine("Hello, C#");
    }
}

