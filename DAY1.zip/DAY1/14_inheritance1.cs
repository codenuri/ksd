﻿using System;

// 주제 : 멤버 이름 충돌과 new
class Base
{
    public int value = 10;
}
class Derived : Base
{
    public int value = 20;
}
class Program
{
    public static void Main()
    {
        Derived d = new Derived();
        Console.WriteLine(d.value); // 20

    }
}