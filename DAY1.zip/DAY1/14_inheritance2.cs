﻿using System;

// 함수 재정의(override)
class Base
{
    public void Foo() { Console.WriteLine("Base Foo"); }   
}
class Derived : Base
{
    public void Foo() { Console.WriteLine("Derived Foo"); }
} 

class Program
{
    public static void Main()
    {
        Base    b = new Base();
        Derived d = new Derived();

        b.Foo();
        d.Foo(); 

        Base bd = new Derived();
        bd.Foo();

    }
}
