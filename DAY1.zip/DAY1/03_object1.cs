﻿using System;

// 핵심 2. 모든 것은 객체이다.

class Program
{
    public static void Main()
    {
    
    
    }
}








