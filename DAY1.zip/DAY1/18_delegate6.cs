﻿using System;

// Func, Action
delegate int Func();

class Delegate6
{
    public static int    Foo()         { Console.WriteLine("Foo"); return 0; }
    public static double Goo()         { Console.WriteLine("Goo"); return 0; }
    public static double Hoo(string s) { Console.WriteLine("Hoo"); return 0; }

    public static void Main()
    {
        Func f1 = Foo;
        Func f2 = Goo;
    }

    public static void F1()      { Console.WriteLine("F1");  }
    public static void F2(int a) { Console.WriteLine("F2");  }
    public static void F3(Animal a) { Console.WriteLine("F3"); }
}
