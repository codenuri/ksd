﻿using System;

// 핵심 5. equality

class Point
{
    public int x;
    public int y;
    public Point(int a, int b) { x = a; y = b; }
}

class Program
{
    public static void Main()
    {
        Point p1 = new Point(1, 1); 
        Point p2 = new Point(1, 1); 

    }
}




