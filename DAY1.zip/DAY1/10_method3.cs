﻿using System;

// 3. param

class Program
{
    public static void foo(int[] arr)
    {
        foreach (var n in arr)
            Console.WriteLine(n);
    }

    public static void Main()
    {
        foo(new int[] { 10, 20, 30 });
    }

    // 주의 사항 - params 는 마지막 인자로만 사용가능.
    public static void f1(int a, params int[] arr) { }
    //public static void f1(params int[] arr, int n) { }  // error
}