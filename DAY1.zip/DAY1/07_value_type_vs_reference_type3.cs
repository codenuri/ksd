﻿using System;

// value_type 과 reference_type 조사

class Program
{
    public static void Main()
    {
        // 1. C# 에서 배열 만들기
        int[] x = new int[] { 1, 2, 3, 4, 5 };

        // 2. 
        int[] y = x;  

    }
}



