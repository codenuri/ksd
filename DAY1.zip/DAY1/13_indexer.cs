﻿using System;

// indexer : 객체를 배열처럼
class Sentense
{
    protected string[] words;
    public Sentense(string s) { words = s.Split(); }
}
class Program
{
    public static void Main()
    {
        Sentense s = new Sentense("we are the world");

        Console.WriteLine(s[3]); //?
        
        s[3] = "frield";
        
    }
}



