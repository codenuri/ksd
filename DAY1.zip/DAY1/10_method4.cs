﻿using System;

// C# 4.0 부터 디폴트 파라미터 가능. 선택적 파라미터(Optional Parameter)라고 부름.
class Program
{
    public static void goo(int x = 0, int y = 0, int z = 0) { }

    public static void Main()
    {
        goo(1, 2, 3);
        goo(1, 2);
        goo(1);

        goo(x: 1, y: 2, z: 3);
        goo(1, z: 3, y: 2);
        goo(y: 2);


        Base b = new Derived();

        b.foo();

    }

}


class Base
{
    public virtual void foo(int n = 10) { Console.WriteLine($"Base : {n}"); }
}
class Derived : Base
{
    public override void foo(int n = 20) { Console.WriteLine($"Derived : {n}"); }
}
